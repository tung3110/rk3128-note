#ifndef AUDIO_H
#define AUDIO_H

#include <stdint.h>
#include <stdbool.h>

#define AUDIO_AUTO_STOP_STREAM 60

void audio_detect_card();
void audio_codec_mute(int is_mute);
void audio_reset_stream_monitor_data(void);
void audio_kill_audio_thread(void);
void audio_reset_stream_state();
bool audio_is_rx_streaming(void);
char *ip_audio_get_last_stream_session(void);
void ip_decoder_change_codec_vol(int volume);
bool audio_is_mute(void);
void audio_stop_rx_streaming();
void audio_start_rx_streaming(char *url, char *session);
void audio_timeout_1s_poll(void);
char *wifi_get_name(void);
void ip_encoder_upstream_start(char *host, int port, char *src, char *pass, char *mount);
bool is_ip_encoder_streaming(void);
char *ip_audio_get_last_rx_stream_url();
char *audio_get_up_stream_url();
uint32_t audio_get_stream_time_in_day();
int audio_get_rx_stream_state();
void audio_default_auto_reset_stream(uint8_t time);
bool audio_is_allow_relay_run(void);

#endif
