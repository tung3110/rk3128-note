#ifndef RING_BUF_H_
#define RING_BUF_H_

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define USE_STATIC_BUFFER 0

#ifndef RING_BUF_MAX_SIZE
#define RING_BUF_MAX_SIZE 16
#endif

typedef struct
{
    uint8_t len;
#if USE_STATIC_BUFFER == 0
    uint8_t need_free;
    uint8_t *data;
    uint8_t *topic;
#else
    uint8_t data[RING_BUF_MAX_SIZE];
#endif
} __attribute__((packed)) ring_buf_data_t;


typedef struct
{
    ring_buf_data_t *buff;
    uint32_t wr_idx; // write index
    uint32_t rd_idx; // read index
    uint32_t size;
} ring_buf_t;

/**
 * @brief               Get number of buffer free in ring_buf 
 * @param[in]           buf Pointer to holder buffer
 * @retval              Numbers of buffer free
 */
uint32_t ring_buf_get_free(ring_buf_t *buf);

/**
 * @brief               Get number of buffer ready to read
 * @param[in]           buf Pointer to holder buffer
 * @retval              Numbers of buffer ready to read
 */
uint32_t ring_buf_get_size_to_read(ring_buf_t *buf);

/**
 * @brief               Write data into buffer
 * @param[in]           buf Pointer to holder buffer
 * @param[in]           msg Data write to buffer
 * @retval              TRUE Write data to buffer succeed
 *                      FALSE Write data to buffer failed, maybe ring buffer is full
 * @Note Please check buffer free before write
 */
bool ring_buf_write(ring_buf_t *buf, ring_buf_data_t *msg);

/**
 * @brief               Read data from buffer
 * @param[in]           buf Pointer to holder buffer
 * @param[in]           msg Data read to buffer
 * @retval              TRUE Read data from buffer succeed
 *                      FALSE Read data from buffer failed, maybe ring buffer is empty
 */
bool ring_buf_read(ring_buf_t *buf, ring_buf_data_t *msg);

/**
 * @brief               Skip data in buffer (increase read index data in buffer)
 * @param[in]           buf Pointer to holder buffer
 * @param[in]           skip_cnt Skip count
 */
void ring_buf_skip(ring_buf_t *buf, uint32_t skip_cnt);


#endif /* RING_BUF_H_ */