#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MQTTAsync.h"
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <arpa/inet.h>
#include "sys/un.h"
#include <fcntl.h>
#include <poll.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <min.h>
#include "min_id.h"
#include <stddef.h>
#include <stdarg.h>
#include "base64.h"
#if defined(_WRS_KERNEL)
#include <OsWrapper.h>
#endif
#include <signal.h>
#include "ip_dbg.h"
#include "app_aes.h"
#include "cJSON.h"
#include "app_serial.h"
#include "gsm.h"
#include "gsm_utilities.h"
#include "lwrb.h"
#include "app_md5.h"
#include "device_config.h"
#include "host_data_layer.h"
#include "board_hw.h"
#include "ip_mqtt.h"
#include "utils.h"
#include "ip_wdt.h"
#include <ip_flk.h>
#include "ip_wdt.h"
#include "audio.h"
#include "mqtt_msg_id.h"
#include "ip_io.h"
#include "wifi_manager.h"
#include "eth_manager.h"
#include "assert.h"
#include "htttn.h"
#include "ota.h"
#include "log_file.h"
#include "minio.h"

#define MAX_IPC_PAYLOAD_SIZE 512
#define IPC_KEY 1234569
#define LOG_TO_FILE_INTERVAL_MS (5000)
#define AUTO_REMOVE_LOG_INTERVAL    (6000000/LOG_TO_FILE_INTERVAL_MS)
#define SOCKET_PATH "/tmp/socketname"
#define BUFFER_SIZE 128

#define IF_4G 0
#define IF_WIFI 1
#define IF_LAN 2

typedef enum
{
    TCP_STATE_INIT,
    TCP_STATE_CONNECTING,
    TCP_STATE_CONNECTED,
    TCP_STATE_DISCONNECTED,
    TCP_STATE_NEED_DESTROY
} tcp_state_t;

typedef struct
{
    long msg_type;
    uint32_t size;
    uint8_t payload[MAX_IPC_PAYLOAD_SIZE];
} ipc_data_t;



typedef enum
{
    GSM_STATE_INIT = 0,
    GSM_STATE_OK = 1,
    GSM_RESET = 2
} gsm_state_t;

typedef struct
{
    uint32_t crc;
} crc_calculate_crc32_ctx_t;

typedef struct
{
    int tick;
    int delay_restarting;
    bool is_error;
    bool is_disconnected;
} ping_if_t;

static ping_if_t m_ping_if[3];
// static const char *IF_DES[24] = {"wwan0", "eth0", "wlan0"};
static const char *IF_DES[24] = {"ppp0", "eth0", "wlan0"};
static pthread_mutex_t m_mutex_dbg, m_mutex_log_file;
static pthread_t p_tid_mqtt, p_tid_socket, p_tid_gsm, p_tid_ping, p_tid_dtmf, p_tid_internet_ping;
static gsm_state_t m_gsm_state = GSM_STATE_INIT;
static uint32_t m_gsm_fsm_counter = 0;
static bool m_4g_up_but_sim_error = false;
static char *gsm_module_name = "NA";
static char m_gsm_operator[33];
static char m_gsm_technology[33];
static char m_gsm_channel[33];
static int m_gsm_csq = 0;
static int m_gsm_modem_index = 0;
static const char* MODEM_PREFIX = "/org/freedesktop/ModemManager1/Modem/";
void gsm_change_state(int new_state);
void ip_flk_save_working_mode(int mode);
void ip_flk_set_last_streaming_master();
void ip_flk_save_tty_flag(int enable);
void ip_flk_save_log_level(int level);
void *log_to_file_thread(void* arg);
static void wifi_scan_callback(wifi_info_t *info, int len);
static void internet_ping();
static void send_command_restart_4g();

static char *m_wifi_scan_reply = NULL;
static int m_mqtt_error_counter = 0;

static lwrb_t m_ringbuffer_log_to_file;
static char *m_log_to_file_buffer = NULL;

static char m_active_interface[32] = "NA";
static bool m_is_ota_running = false;
void *audio_ffmpeg_thread(void* arg);
uint32_t debug_to_tty(const void *buffer, uint32_t len);
void ip_flk_save_log_to_file_flag(int enable);


uint32_t debug_cb_log_to_file(const void *buffer, uint32_t len);
static char m_last_stream_url[512];
static int m_last_streaming_master_level = -1;
static int m_last_emg_level = -1;
static int m_ping = 500;


static int m_ipc_msqid;

static int m_gsm_max_timeout_wait_for_imei = 35;

static bool uart_tx_byte_to_host(void *ctx, uint8_t data);
static void on_host_timeout_callback(void *ctx);
void uqmi_setting_prefer_lte();

bool is_valid_digit_string(char* str)
{
    int leng = strnlen(str, 200);
    if (leng == 0) 
        return false;

    for (int i = 0; i < leng; i++) 
    {
        if (str[i] < '0' || str[i] > '9') 
        {
            return false;
        }
    }
    return true;
}


void crc32_init_context(crc_calculate_crc32_ctx_t *context)
{
    context->crc = 0xFFFFFFFFU;
}

void crc32_step(crc_calculate_crc32_ctx_t *context, uint8_t byte)
{
    context->crc ^= byte;
    for (uint32_t j = 0; j < 8; j++)
    {
        uint32_t mask = (uint32_t) - (context->crc & 1U);
        context->crc = (context->crc >> 1) ^ (0xEDB88320U & mask);
    }
}

uint32_t crc32_finalize(crc_calculate_crc32_ctx_t *context)
{
    return ~context->crc;
}


uint32_t debug_to_tty(const void *buffer, uint32_t len)
{
    // printf("%.*s", len, buffer);
    if (buffer)
    {
        int ttyfd;
        ttyfd = open("/dev/ttyS2", O_WRONLY);
        if (ttyfd!= -1)
        {
            dprintf(ttyfd, "%.*s", len, (char*)buffer);
            close(ttyfd);
        }
        // else
        // {
        //     perror("Open tty failed : ");
        // }
        return len;
    }
    return 0;
}

uint32_t debug_cb_log_to_file(const void *buffer, uint32_t len)
{
    if (buffer && m_log_to_file_buffer)
    {
        size_t written = lwrb_write(&m_ringbuffer_log_to_file, buffer, len);
        if (written != len)
        {
            // printf("Log to ringbuffer file failed %d/%d\r\n", written, len);
        }
        return len;
    }
    return 0;
}


uint32_t ip_dbg_output_cb(const void *buffer, uint32_t len)
{
    if (buffer /*&& m_device_config.log_to_tty*/)
    {
        const uint8_t *ptr = buffer;
        for (uint32_t i = 0; i < len; i++)
        {
            putchar(ptr[i]);
        }
        fflush(stdout);
        return len;
    }
    return 0;
}

bool ip_dbg_lock(bool lock, uint32_t timeout_ms)
{
    if (lock)
    {
        pthread_mutex_lock(&m_mutex_dbg);
    }
    else
    {
        pthread_mutex_unlock(&m_mutex_dbg);
    }
    return true;
}



void gsm_change_state(int new_state)
{
    if (m_gsm_state != new_state)
    {
        A_LOGI("GSM state change from %d to %d\r\n", 
                    m_gsm_state, new_state);
        m_gsm_fsm_counter = 0;
        m_gsm_state = new_state;
    }
}

int get_csq_from_mmcli()
{
    // GET CSQ
    char output[512];
    int csq = 0;
    utils_run_shell_cmd(output, 512, true, "sudo timeout 5 mmcli -m %d --command=\"AT+CSQ\"", m_gsm_modem_index);
    char *p = strstr(output, "+CSQ: ");
    if (p)
    {
        p += strlen("+CSQ: ");
        csq = gsm_utilities_get_number_from_string(0, p);
    }
    return csq;
}

void get_gsm_band()
{
    char output[512];
    int csq = 0;
    utils_run_shell_cmd(output, 512, true, "sudo timeout 5 mmcli -m %d --command=\"AT+QENG=\"servingcell\"\"", m_gsm_modem_index);
    char *p = strstr(output, "+QENG: ");
    if (p)
    {
        p += strlen("+QENG: ");
        gsm_lte_cell_info_t info;
        if (gsm_parse_qeng(p, &info) == 0)
        {
            A_LOGI("Band %d, F %d, %s\r\n", info.band, info.frequency, info.rat);
            gsm_set_last_band(&info);
        }
    }
}

void gsm_state_machine_poll()
{
    static uint32_t gsm_last_poll;
    uint32_t now = time(NULL);
    static uint32_t get_sim_err_counter = 0;
    static bool modem_not_support_csq = false;
    static bool m_use_at_command = false;
    static char *m_at_cmd_port = "/dev/ttyUSB3";
    if (now - gsm_last_poll < 2)
    {
        return;
    }
    gsm_last_poll = now;

    // A_LOGI("gsm_state_machine_poll %d, %d\r\n", m_gsm_state, get_sim_err_counter);
    switch (m_gsm_state)
    {
        case GSM_STATE_INIT:
        {
            m_gsm_technology[0] = 0;
            m_4g_up_but_sim_error = false;
            // Disable echo
            if (m_gsm_fsm_counter == 0)
            {
                char output[512];
                memset(output, 0, sizeof(output));
                utils_run_shell_cmd(output, 512, true, "sudo timeout 3 mmcli -L");
                char *p = strstr(output, MODEM_PREFIX);
                if (p)
                {
                    p += strlen(MODEM_PREFIX);
                    char tmp[512];
                    int idx = 0;
                    memset(tmp, 0, sizeof(tmp));
                    while (*p && *p <= '9' && *p >= '0')
                    {
                        tmp[idx++] = *p++;
                    }
                    m_gsm_modem_index = atoi(tmp);
                    if (*p == ' ') p++;

                    char modem[128];
                    memset(modem, 0, sizeof(modem));
                    char *q = modem;

                    while (*p && *p != '\n')
                    {
                        *q++ = *p++;
                    }
                    A_LOGW("%s: Up, index %d\r\n", modem, m_gsm_modem_index);
                    gsm_set_modem_name(modem);
                    utils_run_shell_cmd(output, sizeof(output), true, "sudo timeout 3 mmcli -m %d --signal-setup=15", m_gsm_modem_index);
                    m_gsm_fsm_counter = 1;
                    return;
                }
                else
                {
                    if (strstr(output, "No modems were found"))
                    {
                        A_LOGW("No modems were found\r\n");
                    }
                    gsm_clear_info();
                    board_hw_sleep(5000);
                    return;
                }
            }
            else if (m_gsm_fsm_counter == 1)    // Get module name
            {
                char output[1024];
                memset(output, 0, sizeof(output));
                utils_run_shell_cmd(output, 512, true, "sudo timeout 5 mmcli -m %d --command=\"AT+QGPS=1\"", m_gsm_modem_index);
                memset(output, 0, sizeof(output));
                utils_run_shell_cmd(output, 1024, true, "sudo timeout 6 mmcli -m %d", m_gsm_modem_index);

                A_LOGI("Modem info:\r\n%s\r\n", output);

                if (strstr(output, "sim-missing") || strstr(output, "state: failed"))
                {
                    A_LOGI("Sim missing: %d\r\n", get_sim_err_counter);
                    m_4g_up_but_sim_error = true;
                    gsm_clear_info();
                    if (strlen(gsm_get_sim_ccid()) || get_sim_err_counter++ > 10)
                    {
                        get_sim_err_counter = 0;
                        m_gsm_fsm_counter = 0;
                        gsm_clear_info();
                        send_command_restart_4g();
                        gsm_change_state(GSM_RESET);
                    }
                    gsm_clear_info();
                    board_hw_sleep(5000);
                    return;
                }
                else
                {
                    // GET IMEI
                    char *p = strstr(output, "equipment id: 86");
                    if (p)
                    {
                        p += strlen("equipment id:");
                        char gsm_imei[48];
                        memset(gsm_imei, 0, sizeof(gsm_imei));
                        gsm_utilities_copy_parameters(p, gsm_imei, ' ', '\n');
                        gsm_set_imei(gsm_imei);
                        ip_flk_set_4g_imei(gsm_imei);
                        A_LOGI("IMEI %s\r\n", gsm_imei);
                    }
                }

                // Get card
                char *p = strstr(output, "model:");
                if (p)
                {
                    p += strlen("model:");
                    char tmp_card[25];
                    memset(tmp_card, 0, sizeof(tmp_card));
                    gsm_utilities_copy_parameters(p, tmp_card, ' ', '\n');
                    gsm_set_operator(tmp_card);
                    if (strstr(tmp_card, "EC20"))
                    {
                        m_use_at_command = true;
                        modem_not_support_csq = true;
                        m_at_cmd_port ="/dev/ttyUSB3";
                        gsm_set_serial_port(m_at_cmd_port);
                    }
                    A_LOGI("Card : %s\r\n", tmp_card);
                }
            }
            else if (m_gsm_fsm_counter == 2)    // Get module name
            {
                char output[1024];
                memset(output, 0, sizeof(output));
                utils_run_shell_cmd(output, 1024, true, "sudo timeout 6 mmcli --sim %d", m_gsm_modem_index);

                // GET IMSI
                char *p = strstr(output, "imsi: ");
                if (p)
                {
                    p += strlen("imsi:");
                    char sim_imsi[48];
                    memset(sim_imsi, 0, sizeof(sim_imsi));
                    gsm_utilities_copy_parameters(p, sim_imsi, ' ', '\n');
                    gsm_set_sim_imsi(sim_imsi);
                    A_LOGI("SIM IMSI %s\r\n", sim_imsi);
                }

                // Get Operator
                p = strstr(output, "operator name:");
                if (p)
                {
                    p += strlen("operator name:");
                    char tmp_name[25];
                    memset(tmp_name, 0, sizeof(tmp_name));
                    gsm_utilities_copy_parameters(p, tmp_name, ' ', '\n');
                    gsm_set_operator(tmp_name);
                    A_LOGI("Name %s\r\n", tmp_name);
                }

                // ccid
                p = strstr(output, "ccid: ");
                if (p)
                {
                    p += strlen("ccid:");
                    char sim_ccid[48];
                    memset(sim_ccid, 0, sizeof(sim_ccid));
                    gsm_utilities_copy_parameters(p, sim_ccid, ' ', '\n');
                    gsm_set_sim_ccid(sim_ccid);
                    m_gsm_max_timeout_wait_for_imei = 0;
                    A_LOGI("SIM CCID %s\r\n", sim_ccid);
                }
                
                int tmp_csq = get_csq_from_mmcli();
                if (tmp_csq > 0)
                {
                    m_gsm_csq = tmp_csq;
                    gsm_set_csq(m_gsm_csq);
                    A_LOGI("RSSI %d\r\n", m_gsm_csq);
                }

                get_gsm_band();
                m_gsm_state = GSM_STATE_OK;
                m_gsm_fsm_counter = 0;
                ip_mqtt_heartbeat_soon(2);
                return;
            }
            else
            {
                return;
            }
            m_gsm_fsm_counter += 1;
        }
            break;
        
        case GSM_STATE_OK:
        {
            // # Auto get csq
            static uint32_t auto_poll_gps = 0;
            m_4g_up_but_sim_error = false;
            if ((m_gsm_fsm_counter % 45) == 0)
            {
                char output[512];
                memset(output, 0, sizeof(output));
                if (modem_not_support_csq == false)
                {
                    utils_run_shell_cmd(output, 512, true, "sudo timeout 5 mmcli -m %d --command=\"AT+CSQ\"", m_gsm_modem_index);
                    if (strstr(output, "modem has no extended signal capabilities"))
                    {
                        modem_not_support_csq = true;
                    }
                    else
                    {
                        // GET CSQ
                        char *p = strstr(output, "+CSQ: ");
                        if (p)
                        {
                            p += strlen("+CSQ: ");
                            m_gsm_csq = gsm_utilities_get_number_from_string(0, p);
                            gsm_set_csq(m_gsm_csq);
                            A_LOGI("RSSI %d\r\n", m_gsm_csq);
                        }
                    }
                }

                if (modem_not_support_csq)
                {
                    m_gsm_csq = gsm_at_get_csq();
                }
            }
            else if ((m_gsm_fsm_counter % 121) == 0)
            {
                char output[512];
                memset(output, 0, sizeof(output));
                utils_run_shell_cmd(output, 512, true, "sudo timeout 6 mmcli --sim %d", m_gsm_modem_index);
                char *p = strstr(output, "ccid: ");
                if (p)
                {
                    m_gsm_max_timeout_wait_for_imei = 0;
                    p += strlen("ccid:");
                    char sim_ccid[48];
                    memset(sim_ccid, 0, sizeof(sim_ccid));
                    gsm_utilities_copy_parameters(p, sim_ccid, ' ', '\n');
                    if (strlen(sim_ccid) < 10)
                    {
                        A_LOGE("Sim not inserted\r\n");
                        get_sim_err_counter = 0;
                        m_gsm_fsm_counter = 0;
                        gsm_clear_info();
                        send_command_restart_4g();
                        gsm_change_state(GSM_RESET);
                        return;
                    }
                }
            }
            m_gsm_fsm_counter += 1;
            m_gsm_max_timeout_wait_for_imei = 0;
            if ((m_gsm_csq == 0 || m_gsm_csq == 99) && modem_not_support_csq == false)
            {
                m_gsm_fsm_counter = 45;
                get_sim_err_counter++;
                if (get_sim_err_counter > 20)
                {
                    get_sim_err_counter = 0;
                    m_gsm_fsm_counter = 0;
                    auto_poll_gps = 0;
                    gsm_change_state(GSM_RESET);
                }
            }

            if (auto_poll_gps++ >= 30)
            {
                auto_poll_gps = 0;
                char output[512];
                printf("Poll GSP\r\n");
                utils_run_shell_cmd(output, 512, true, "sudo timeout 5 mmcli -m %d --command=\"AT+QGPSGNMEA=\"RMC\"\"", m_gsm_modem_index);
                gps_coordinate_t gps_pos;
                if (gsm_parse_gnrmc(output,  &gps_pos))
                {
                    gsm_set_gps(&gps_pos);
                }
                
            }
        }
            break;

        case GSM_RESET: 
        // TODO
            gsm_clear_info();
            gsm_change_state(GSM_STATE_INIT);
            break;
        default:
            break;
    }
}

void* gsm_thread(void* arg)
{
    A_LOGW("Start 4G\r\n");
#ifndef BOARD_HAS_4G
    goto loop;
#endif
    static int monitor_current_time = 0;
loop:
    while (1)
    {
        ip_wdt_feed(WDT_THREAD_GSM);
    #ifndef BOARD_HAS_4G
        board_hw_sleep(500);
        continue;
    #endif

        internet_ping();

        gsm_state_machine_poll();
        if (monitor_current_time++ == 20)
        {
            monitor_current_time = 0;
            time_t rawtime;
            struct tm * timeinfo;

            time(&rawtime);
            timeinfo = localtime (&rawtime);
            if (timeinfo->tm_hour == 23 && timeinfo->tm_min == 59)
            {
                ip_mqtt_dbg("Auto reset");
                board_hw_sleep(2000);
                utils_reboot();
                board_hw_sleep(30000);
            }
        }
        board_hw_sleep(500);
    }
    pthread_exit(NULL);
}


#define READ   0
#define WRITE  1
FILE * popen2(char *command, char *type, int *pid)
{
    pid_t child_pid;
    int fd[2];
    pipe(fd);

    if((child_pid = fork()) == -1)
    {
        perror("fork");
        exit(1);
    }

    /* child process */
    if (child_pid == 0)
    {
        if (type == "r")
        {
            close(fd[READ]);    //Close the READ end of the pipe since the child's fd is write-only
            dup2(fd[WRITE], 1); //Redirect stdout to pipe
        }
        else
        {
            close(fd[WRITE]);    //Close the WRITE end of the pipe since the child's fd is read-only
            dup2(fd[READ], 0);   //Redirect stdin to pipe
        }

        setpgid(child_pid, child_pid); //Needed so negative PIDs can kill children of /bin/sh
        execl("/bin/sh", "/bin/sh", "-c", command, NULL);
        exit(0);
    }
    else
    {
        if (type == "r")
        {
            close(fd[WRITE]); //Close the WRITE end of the pipe since parent's fd is read-only
        }
        else
        {
            close(fd[READ]); //Close the READ end of the pipe since parent's fd is write-only
        }
    }

    *pid = child_pid;

    if (type == "r")
    {
        return fdopen(fd[READ], "r");
    }

    return fdopen(fd[WRITE], "w");
}

// int pclose2(FILE * fp, pid_t pid)
// {
//     int stat;

//     fclose(fp);
//     while (waitpid(pid, &stat, 0) == -1)
//     {
//         if (errno != EINTR)
//         {
//             stat = -1;
//             break;
//         }
//     }

//     return stat;
// }



void uqmi_setting_prefer_lte()
{
#ifndef BOARD_HAS_4G
    return;
#endif
    utils_run_shell_cmd(NULL, 0, true, "/usr/bin/timeout 5 uqmi --set-network-modes lte --device=/dev/cdc-wdm0");
}



void export_gpio()
{
    // Export GPIO
    // utils_run_shell_cmd(NULL, 0, true, "echo 41 > /sys/class/gpio/export");
    // utils_run_shell_cmd(NULL, 0, true, "echo 42 > /sys/class/gpio/export");
    // utils_run_shell_cmd(NULL, 0, true, "echo 45 > /sys/class/gpio/export");
    // utils_run_shell_cmd(NULL, 0, true, "echo 46 > /sys/class/gpio/export");

    // utils_run_shell_cmd(NULL, 0, true, "echo out > /sys/class/gpio/gpio41/direction");
    // utils_run_shell_cmd(NULL, 0, true, "echo out > /sys/class/gpio/gpio42/direction");
    // utils_run_shell_cmd(NULL, 0, true, "echo out > /sys/class/gpio/gpio45/direction");
    // utils_run_shell_cmd(NULL, 0, true, "echo out > /sys/class/gpio/gpio46/direction");
}


static int ttn_compare_priority(char *new_master, char *current_master)
{
    int new = app_flash_find_group_priority(new_master);
    int old = app_flash_find_group_priority(current_master);

    if (new > old)
        return 1;
    if (new == old)
        return 0;
    return -1;
}

static void ttn_process_stream_cmd(int priority, char *master, char *url, 
                                    int emergency_level, int cmd_code, 
                                    int delay_relay, int vol, bool is_me)
{
    A_LOGI("Master [%d], serial %s, url %s, em %d, cmd %d\r\n", 
                    priority, master, url, emergency_level, cmd_code);
    bool do_stream = false;
    char new_stream_url[256];
    bool delay_stream = false;

    sprintf(new_stream_url, "%s", url);

    int master_priority = app_flash_find_group_priority(master);
    if (master_priority == -1)
    {
        A_LOGW("Invalid master priority %s\r\n", master);
    }

    if (is_me && master_priority != -1 && ip_flk_get_working_mode() != 4) // mode internet
    {
        // Process stream running command
        if (cmd_code == CMD_STREAM_RUNNING | cmd_code == CMD_STREAM_START)
        {
            do_stream = true;
        }

        if (do_stream)
        {
            audio_default_auto_reset_stream(AUDIO_AUTO_STOP_STREAM);

            if (master_priority > m_last_streaming_master_level
                || (master_priority == m_last_streaming_master_level 
                    && strcmp(new_stream_url, m_last_stream_url)
                    && emergency_level > m_last_emg_level))
            {
                A_LOGI("Start streaming by url %s\r\n", new_stream_url);
                if (m_last_streaming_master_level != -1)
                {
                    // Higher master
                    ip_mqtt_dbg("Start stream by higher master %s, url %s", 
                                    master, new_stream_url);
                    log_file_write("Start stream by higher master %s, url %s", 
                                    master, new_stream_url);
                }
                else
                {
                    ip_mqtt_dbg("Start stream on master %s, url %s", 
                                    master, new_stream_url);
                    log_file_write("Start stream on master %s, url %s\r\n", 
                                    master, new_stream_url);
                }
                m_last_emg_level = emergency_level;
                m_last_streaming_master_level = master_priority;

                char *p_master = ip_flk_get_last_streaming_master();
                sprintf(p_master, "%s", master);
                ip_flk_set_last_streaming_master();
                snprintf(m_last_stream_url, 512, "%s", new_stream_url);
                audio_start_rx_streaming(m_last_stream_url, p_master);
            }
            return;
        }

        // Process stream stop command
        if (cmd_code == CMD_STREAM_STOP 
            && audio_is_rx_streaming()
            && (m_last_streaming_master_level == master_priority))
        {
            A_LOGW("Stop stream\r\n");
            ip_mqtt_dbg("Stop current stream on master %s", master);
            log_file_write("Stop current stream on master %s\r\n", master);
            board_hw_sleep(5000); // Sleep 5s de flush het data
            audio_stop_rx_streaming();
            m_last_streaming_master_level = -1;
            m_last_emg_level = -1;
            audio_default_auto_reset_stream(0);
            // audio_codec_mute(1);
            memset(m_last_stream_url, 0, sizeof(m_last_stream_url));
        }
    }
}

void ttn_on_device_mode_change(char *value)
{
    if (!value)
    {
        return;
    }
    int current_mode = ip_flk_get_working_mode();
    uint8_t new_mode = utils_get_number_from_string(0, value);
    ip_mqtt_dbg("Received mode %d, current %d", new_mode, current_mode);

    if (new_mode == current_mode)
    {
        return;
    }


    A_LOGW("Mode change from %d to %d\r\n", current_mode, new_mode);
    if (new_mode == OPERATION_MODE_NO_OPERATION)       // STOP mode
    {
        audio_codec_mute(1);
        audio_stop_rx_streaming();
    }
    else if (new_mode == OPERATION_MODE_INTERNET && ip_flk_get_volume(0))
    {
        audio_codec_mute(0);
    }
    ip_flk_save_working_mode(new_mode);
    // TODO
    // m_send_config_to_svr = true;
}

static void handle_get_config_by_code(int code)
{
    char *get_msg = malloc(512);
    char *get_value = malloc(512);
    if (!get_msg || !get_value)
    {
        return;
    }
    int valid_msg = 0;

    switch (code)
    {
    case CONFIG_GET_DEVICE_NAME:
    {
        valid_msg++;
        sprintf(get_value, "\"C\":[{\"C\":%d,\"V\":\"%s\"}]",
                code, 
                ip_flk_get_device_name());
    }
        break;
    
    default:
        break;
    }

    if (valid_msg)
    {
        char topic[32];
        sprintf(topic, "tx/%s/config", ip_flk_get_4g_imei());
        sprintf(get_msg, "{\"Message\":{%s},\"Id\":2,\"Time\":%u,\"Sender\":\"%s\"}",
                    get_value,
                    utils_sys_get_second(),
                    ip_flk_get_4g_imei()
                );
        ip_mqtt_send_raw(topic, get_msg);
    }

    free(get_msg);
    free(get_value);
}

static void ttn_mqtt_process_msq_id(cJSON* root, cJSON* message, uint32_t id, char *topic_name)
{
    bool send_cfg = false;
    switch (id)
    {
        case MSG_ID_DEVICE_CONFIG:
        {
            A_LOGI("Device config msg\r\n");
            cJSON *device_name, *groups, *group_conf;

            device_name = cJSON_GetObjectItem(message, "Name");
            if (device_name)
            {
                A_LOGI("Device name %s\r\n", device_name->valuestring);
                app_flash_set_human_device_name(device_name->valuestring);
            }

            groups = cJSON_GetObjectItem(message, "Groups");
            if (groups && cJSON_IsArray(groups))
            {
                A_LOGI("Group config size %d\r\n", cJSON_GetArraySize(groups));
                // uint32_t group_count = 0;

                app_flash_remove_all_temporary_group();
                cJSON_ArrayForEach(group_conf, groups)
                {
                    cJSON *id, *master_type, *priority;
                    id = cJSON_GetObjectItem(group_conf, "Id");
                    master_type = cJSON_GetObjectItem(group_conf, "MasterType");
                    priority = cJSON_GetObjectItem(group_conf, "Priority");
                    if (id && master_type && priority)
                    {
                        A_LOGW("Master %s, type %d, priority %d\r\n", 
                                    id->valuestring, 
                                    master_type->valueint, 
                                    priority->valueint);
                        app_flash_set_temporary_group_name(id->valuestring, priority->valueint);
                    }
                }
                
                if (app_flash_commit_temporary_group_if_needed())
                {
                    send_cfg = true;
                }
                else
                {   
                    ip_mqtt_dbg("Same group, nothing to change");
                }
            }

            if (send_cfg)
            {
                ip_mqtt_resub_all_master();
            }
        }
            break;

        case MSG_ID_OTA_APP:
        {
            cJSON *download_url;
            download_url = cJSON_GetObjectItem(message, "url");
            if (download_url && strstr(download_url->valuestring, "http"))
            {
                ota_start(download_url->valuestring, "", "");
            }
        }
            break;

        case MSG_ID_GET_CFG:
            {
                cJSON *c_obj;
                c_obj = cJSON_GetObjectItem(message, "Obj");
                if (c_obj && cJSON_IsArray(c_obj))       // check object
                {
                    A_LOGI("Obj msg\r\n");
                    cJSON *ele;
                    cJSON_ArrayForEach(ele, c_obj)
                    {
                        if (cJSON_IsNumber(ele))
                        {
                            handle_get_config_by_code(ele->valueint);
                        }
                    }
                }
            }
            break;
            
        case MSG_ID_SET_CFG:
        {
            cJSON *c_cmd, *c_obj, *c_value;
            char *set_msg = NULL;
            c_value = cJSON_GetObjectItem(message, "V");
            c_obj = cJSON_GetObjectItem(message, "Obj");
            int cfg_count = 0;
            
            if (c_value && cJSON_IsString(c_value))
            {
                set_msg = strstr(c_value->valuestring, "SET,");
            }
            else if (c_obj && cJSON_IsArray(c_obj))       // check object
            {
                A_LOGV("Obj msg\r\n");
                cJSON *ele;
                cJSON_ArrayForEach(ele, c_obj)
                {
                    int new_count = 0;
                    c_cmd = cJSON_GetObjectItem(ele, "C");
                    c_value = cJSON_GetObjectItem(ele, "V");
                    if (c_value && cJSON_IsString(c_value))
                    {
                        set_msg = strstr(c_value->valuestring, "SET,");
                    }
                    if (!set_msg && c_cmd && cJSON_IsNumber(c_cmd) && c_value)
                    {
                        switch (c_cmd->valueint)
                        {
                            case CONFIG_MEET_VOLUME_PERCENT:
                            {
                                // Set vol
                                uint8_t new_vol = utils_get_number_from_string(0, c_value->valuestring);
                                if (new_vol > 100)
                                {
                                    new_vol = 100;
                                }
                                A_LOGI("Set volume to %d/%s\r\n", new_vol, c_value->valuestring);
                                int old_vol = ip_flk_get_volume(0);
                                ip_decoder_change_codec_vol(new_vol);
                                if (new_vol != old_vol && new_vol <= 100 && new_vol >= 0)
                                {
                                    A_LOGI("Volume change from %d to %d\r\n", 
                                                            old_vol, 
                                                            new_vol);
                                    ip_flk_set_volume(0, new_vol);

                                    cfg_count++;
                                    if (new_vol == 0)
                                    {
                                        audio_codec_mute(1);
                                    }
                                    else
                                    {
                                        audio_codec_mute(0);
                                    }
                                    send_cfg = true;
                                }
                            }
                                break;

                            case CONFIG_VS_SPEAKER_WORKING_MODE:
                            {         
                                if (c_value && cJSON_IsString(c_value))
                                {
                                    // TODO
                                    log_file_write("New mode %s\r\n", c_value->valuestring);
                                    ttn_on_device_mode_change(c_value->valuestring);
                                }
                                else
                                {
                                    new_count = 0;
                                }
                            }
                                break;

                            case CONFIG_SHELL:
                                if (c_value && cJSON_IsString(c_value))
                                {
                                    char *output = calloc(2048, 1);
                                    assert(output);
                                    utils_run_shell_cmd(output, 2048, true, "%s", c_value->valuestring);
                                    if (strlen(output))
                                    {
                                        char *q = output + strlen(output) - 1;
                                        if (*q == '\n') *q = 0;
                                        ip_mqtt_dbg("%s", output);
                                    }
                                    free(output);
                                }
                                    break;

                            case CONFIG_LOG_LEVEL:
                                if (c_value && cJSON_IsNumber(c_value) && ip_flk_get_log_level() != c_value->valueint)
                                {
                                    ip_flk_save_log_level(c_value->valueint);
                                }
                                break;

                            case CONFIG_VS_SPEAKER_WIFI_DISABLE:
                                A_LOGI("Disable wifi\r\n");
                                utils_run_shell_cmd(NULL, 0, true, "sudo timeout 5 nmcli radio wifi off");
                                break;
                            case CONFIG_UPLOAD_MINIO_LOG:
                                if (c_value && cJSON_IsString(c_value))
                                {
                                    char log_file[128];
                                    sprintf(log_file, ".%s/%s_%s", LOG_DIR, ip_flk_get_4g_imei(), c_value->valuestring);
                                    ip_mqtt_dbg("Upload log file %s", log_file);
                                    minio_upload_log(log_file);
                                }
                                break;

                            case CONFIG_RESTART_APP:
                            case CONFIG_SAFE_REBOOT:
                            case CONFIG_SAFE_SHUTDOWN: 
                            case CONFIG_EMERGENCY_REBOOT: 
                            case CONFIG_EMERGENCY_SHUTDOWN:
                                log_file_write("Reset by reboot cmd\r\n");
                                ip_mqtt_dbg("Reset by reboot cmd");
                                board_hw_sleep(2000);
                                utils_reboot();
                                break; 
                            case CONFIG_MQTT_SRV:
                            {
                                A_LOGI("Config mqtt broker\r\n");
                                if (c_value && cJSON_IsString(c_value))
                                {
                                    char *cfg_str = cJSON_GetStringValue(c_value);
                                    cJSON* child_obj = cJSON_Parse(cfg_str);;
                                    if (child_obj && ip_mqtt_get_state() == IP_MQTT_STATE_CONNECTED)
                                    {
                                        int diff = 0;
                                        cJSON *c_mqtt_server = cJSON_GetObjectItem(child_obj, "Url");
                                        cJSON *c_mqtt_user = cJSON_GetObjectItem(child_obj, "Usr");
                                        cJSON *c_mqtt_pass = cJSON_GetObjectItem(child_obj, "Pw");
                                        cJSON *c_mqtt_port = cJSON_GetObjectItem(child_obj, "Port");
                                        if (c_mqtt_server && c_mqtt_user && c_mqtt_pass && c_mqtt_port
                                            && cJSON_IsString(c_mqtt_server)
                                            && cJSON_IsString(c_mqtt_user)
                                            && cJSON_IsString(c_mqtt_pass)
                                            && cJSON_IsNumber(c_mqtt_port))
                                        {
                                            broker_info_t new_brk;
                                            memset(&new_brk, 0, sizeof(broker_info_t));
                                            int port = -1;
                                            if (strstr(c_mqtt_server->valuestring, "mqtt://"))
                                            {
                                                sprintf(new_brk.url, "%s", c_mqtt_server->valuestring+7);
                                            }
                                            else if (strstr(c_mqtt_server->valuestring, "tcp://"))
                                            {
                                                sprintf(new_brk.url, "%s", c_mqtt_server->valuestring+6);
                                            }
                                            else
                                            {
                                                sprintf(new_brk.url, "%s", c_mqtt_server->valuestring);
                                            }
                                            

                                            if (strcmp(ip_flk_mqtt_get_url(), new_brk.url) != 0)
                                            {
                                                A_LOGI("New mqtt url: %s -> %s\r\n", ip_flk_mqtt_get_url(), new_brk.url);
                                                diff++;
                                                new_count++;
                                            }
                                            else
                                            {
                                                A_LOGI("Same broker\r\n");
                                                sprintf(new_brk.url, "%s", ip_flk_mqtt_get_url());
                                            }

                                            if (strcmp(ip_flk_mqtt_get_username(), c_mqtt_user->valuestring) != 0)
                                            {
                                                sprintf(new_brk.username, "%s", c_mqtt_user->valuestring);

                                                A_LOGI("New mqtt username: %s\r\n", new_brk.username);

                                                diff++;
                                                new_count++;
                                            }
                                            else
                                            {
                                                A_LOGI("Same username\r\n");
                                                sprintf(new_brk.username, "%s", ip_flk_mqtt_get_username());
                                            }

                                            if (strcmp(ip_flk_mqtt_get_pwd(), c_mqtt_pass->valuestring) != 0)
                                            {
                                                sprintf(new_brk.password, "%s", c_mqtt_pass->valuestring);

                                                A_LOGI("New mqtt password: %s\r\n", new_brk.password);

                                                diff++;
                                                new_count++;
                                            }
                                            else
                                            {
                                                A_LOGI("Same password\r\n");
                                                sprintf(new_brk.password, "%s", ip_flk_mqtt_get_pwd());
                                            }   

                                            if (ip_flk_mqtt_get_port() != c_mqtt_port->valueint && c_mqtt_port->valueint > 0)
                                            {
                                                diff++;
                                                new_brk.port = c_mqtt_port->valueint;
                                            }
                                            else
                                            {
                                                new_brk.port = ip_flk_mqtt_get_port();
                                            }

                                            if (diff) 
                                            {
                                                A_LOGI("Try new broker\r\n");
                                                log_file_write("Received config %s\r\n", c_value->valuestring);
                                                new_count = 0;
                                                ip_mqtt_try_new_broker(&new_brk);
                                                cfg_count++;
                                                // send_cfg = true;
                                            }
                                        }
                                        else
                                        {
                                            A_LOGW("Invalid %d%d%d%d", c_mqtt_server ? 1 : 0,
                                                        c_mqtt_user ? 1 : 0,
                                                        c_mqtt_pass ? 1 : 0,
                                                        c_mqtt_port ? 1 : 0);
                                        }
                                        cJSON_Delete(child_obj);
                                    }
                                    else
                                    {
                                        A_LOGE("Invalid config value\r\n");
                                    }
                                }
                            }
                                break;
                            case CONFIG_MQTT_V1_COMPATIBILITY:
                            {

                            }
                                break;

                            case CONFIG_OTA_RK3:
                                if (c_value && cJSON_IsString(c_value) && strstr(c_value->valuestring, "http"))
                                {
                                    ota_start(c_value->valuestring, "", "");
                                }
                                break;

                            case CONFIG_CONNECT_NEW_WIFI:
                            {
                                if (c_value && cJSON_IsString(c_value))
                                {
                                    // get wifiname and password
                                    char ssid[50], password[50];
                                    memset(ssid, 0, sizeof(ssid));
                                    memset(password, 0, sizeof(password));
    
                                    char *token = strtok(c_value->valuestring, ",");
                                    if (token != NULL) 
                                    {
                                        strncpy(ssid, token, sizeof(ssid) - 1);
                                        ssid[sizeof(ssid) - 1] = '\0';
                                        
                                        token = strtok(NULL, ",");
                                        if (token != NULL) 
                                        {
                                            strncpy(password, token, sizeof(password) - 1);
                                            password[sizeof(password) - 1] = '\0';
                                        } 
                                        else 
                                        {
                                            password[0] = '\0'; // Ensure password is empty if not found
                                        }
                                    }
                                    printf("SSID: %s\n", ssid);
                                    printf("Password: %s\n", password);
                                    ip_mqtt_dbg("Connecting to %s, %s", ssid, password);
                                    wifi_manager_connect(ssid, password);
                                }
                            }
                                break;
                            
                            case CONFIG_VS_SPEAKER_SPK_DETECT:
                            {
                                if (c_value && cJSON_IsNumber(c_value))
                                {
                                    ip_flk_set_speaker_class(c_value->valueint);
                                }
                            }
                                break;

                            default:
                                new_count = 0;
                                break;
                        }
                        cfg_count += new_count;
                    }
                }
            }

            if (set_msg)
            {
                A_LOGI("Process set message %s\r\n", set_msg);
                // TODO
                // int config_changed = 0;
                // int do_resub = 0;
                // mqtt_process_set_config_msg(set_msg, &config_changed, &do_resub);
                // if (config_changed)
                // {
                //     // TODO
                //     // m_send_config_to_svr = true;
                // }

                // if (do_resub)
                // {
                //     // TODO
                //     // m_mqtt_do_resub = true;
                // }
            }
            // TODO
            // if (cfg_count)
            //     m_send_config_to_svr = true;
        }
            break;

        case MSG_ID_JOIN_ROOM_CMD:
        {
            A_LOGI("Join room cmd topic %s\r\n", topic_name);
            char *group_id = strstr(topic_name, "/");
            if (group_id) group_id++;

            int delay_relay = 0;
            int vol = -1;
            bool is_me = false;
            bool join = false;
            int prio = 0;

            cJSON *c_master = NULL, *c_serial, *c_is_all, *c_vol, *c_priority = NULL, *c_delay_turn_on_relay, *c_uri, *c_join, *c_link_v1, *c_prio;
            cJSON *room = cJSON_GetObjectItem(message, "Room");
            if (room)
            {
                c_master = cJSON_GetObjectItem(room, "Master");
                c_priority = cJSON_GetObjectItem(room, "Priority");
                A_LOGI("Room from master %s, priority %d\r\n", c_master->valuestring, c_priority->valueint);
            }
            c_is_all = cJSON_GetObjectItem(message, "IsAll");
            c_uri = cJSON_GetObjectItem(message, "Icecast");
            c_link_v1 = cJSON_GetObjectItem(message, "UriV1");
            c_delay_turn_on_relay = cJSON_GetObjectItem(message, "DelayTurnOnRelay");
            c_vol = cJSON_GetObjectItem(message, "Vol");
            c_serial = cJSON_GetObjectItem(message, "Serials");
            c_join = cJSON_GetObjectItem(message, "J");
            c_prio = cJSON_GetObjectItem(message, "E");
            if (c_prio && cJSON_IsNumber(c_prio))
            {
                prio = c_prio->valueint;
            }

            if (c_join && cJSON_IsTrue(c_join))
            {
                join = true;
            }
            
            if (c_uri)
            {
                A_LOGI("Uri %s\r\n", c_uri->valuestring);
            }

            if (c_is_all && cJSON_IsTrue(c_is_all))
            {
                is_me = true;
            }
            else if (c_serial)
            {
                cJSON *ele;
                cJSON_ArrayForEach(ele, c_serial)
                {
                    if (strstr(ele->valuestring, ip_flk_get_4g_imei()))
                    {
                        is_me = true;
                        break;
                    }
                }
            }

            A_LOGV("Allow me %d\r\n", is_me ? 1 : 0);

            if (c_delay_turn_on_relay != NULL) delay_relay = c_delay_turn_on_relay->valueint;
            if (c_vol != NULL) vol = c_vol->valueint;

            if (join && c_master && c_is_all && c_priority && c_uri && group_id && strstr(c_uri->valuestring, "http://"))
            {
                ttn_process_stream_cmd(c_priority->valueint, group_id/*c_master->valuestring*/, c_uri->valuestring, prio,
                                        CMD_STREAM_RUNNING, delay_relay, vol, is_me);
            }
        }
            break;

        case MSG_ID_STREAM_COMMAND:
        {
            A_LOGI("Stream cmd\r\n");

            cJSON *c_master, *c_cmd, *c_serial, *c_is_all, *c_info, *c_vol, *c_priority, *c_emergency, *c_type, *c_delay_turn_on_relay, *c_uri, *c_link_v1;
            c_master = cJSON_GetObjectItem(message, "Master");
            c_is_all = cJSON_GetObjectItem(message, "IsAll");
            c_cmd = cJSON_GetObjectItem(message, "CmdCode");
            c_info = cJSON_GetObjectItem(message, "Info");
            c_priority = cJSON_GetObjectItem(message, "P");
            c_emergency = cJSON_GetObjectItem(message, "E");
            c_type = cJSON_GetObjectItem(message, "T");
            c_delay_turn_on_relay = cJSON_GetObjectItem(message, "DelayTurnOnRelay");
            c_vol = cJSON_GetObjectItem(message, "Vol");
            c_serial = cJSON_GetObjectItem(message, "Serials");
            if (c_info && cJSON_IsObject(c_info))
            {
                c_uri = cJSON_GetObjectItem(c_info, "Uri");
                c_link_v1 = cJSON_GetObjectItem(c_info, "UriV1");
                if (c_link_v1 && cJSON_IsString(c_link_v1) && strstr(c_link_v1->valuestring, "http"))
                {
                    //c_uri = c_link_v1;
                }
            }
            else
            {
                c_uri = NULL;
            }

            int delay_relay = 0;
            int vol = -1;
            bool is_me = false;
            if (c_is_all && cJSON_IsTrue(c_is_all))
            {
                is_me = true;
            }
            else if (c_serial)
            {
                cJSON *ele;
                cJSON_ArrayForEach(ele, c_serial)
                {
                    if (strstr(ele->valuestring, ip_flk_get_4g_imei()))
                    {
                        is_me = true;
                        break;
                    }
                }
            }

            if (c_delay_turn_on_relay != NULL) delay_relay = c_delay_turn_on_relay->valueint;
            if (c_vol != NULL) vol = c_vol->valueint;

            if (c_master && c_is_all && c_info && c_priority && c_emergency 
                && c_type && c_uri && c_cmd)
            {
                bool valid_type = true;
                if (/*strstr(c_uri->valuestring, ".mp3") || */
                    strstr(c_uri->valuestring, ".wav") 
                    // || strstr(c_uri->valuestring, ".m3u8") 
                    // || strstr(c_uri->valuestring, ".aac") 
                    || strstr(c_uri->valuestring, ".m4a"))
                {
                    valid_type = false;
                }

                if (valid_type)
                {
                    char *group_id = c_master->valuestring;
                    int master_priority = app_flash_find_group_priority(group_id);
                    if (master_priority == -1 && strlen(group_id) == 15 && memcmp(group_id, "86", 2) == 0)
                    {
                        char *tmp_g = strstr(topic_name, "tx/");
                        if (tmp_g) group_id = tmp_g+3;
                        A_LOGI("Invalid master priority select new %s\r\n", group_id);
                    }

                    ttn_process_stream_cmd(c_priority->valueint, group_id, c_uri->valuestring, c_emergency->valueint,
                                        c_cmd->valueint, delay_relay, vol, is_me);
                }
                else
                {
                    A_LOGW("Invalid url %s\r\n", c_uri->valuestring);
                }
            }

        }
            break;
        
        case MSG_ID_EXIT_ROOM_CMD:
        {
            A_LOGI("Exit cmd topic %s\r\n", topic_name);
            char *group_id = strstr(topic_name, "/");
            if (group_id) group_id++;

            bool is_me = false;
            cJSON *c_master = NULL, *c_serial, *c_is_all, *c_priority = NULL;
            cJSON *room = cJSON_GetObjectItem(message, "Room");
            if (room)
            {
                c_master = cJSON_GetObjectItem(room, "Master");
                c_priority = cJSON_GetObjectItem(room, "Priority");
                A_LOGI("Room from master %s, priority %d\r\n", c_master->valuestring, c_priority->valueint);
            }
            c_is_all = cJSON_GetObjectItem(message, "IsAll");
            c_serial = cJSON_GetObjectItem(message, "Serials");
            
            if (c_is_all && cJSON_IsTrue(c_is_all))
            {
                is_me = true;
            }
            else if (c_serial)
            {
                cJSON *ele;
                cJSON_ArrayForEach(ele, c_serial)
                {
                    if (strstr(ele->valuestring, ip_flk_get_4g_imei()))
                    {
                        is_me = true;
                        break;
                    }
                }
            }

            A_LOGV("Allow me %d\r\n", is_me ? 1 : 0);
            if (c_master && c_is_all && c_priority && group_id)
            {
                ttn_process_stream_cmd(c_priority->valueint, group_id/*c_master->valuestring*/, "", 0,
                                        CMD_STREAM_STOP, 0, 0, is_me);
            }
        }
            break;
    default:
        break;
    }

    // // TODO
    // if (send_cfg)
    // {
    //     m_send_config_to_svr = true;
    // }
}


bool atth_mqtt_parse(const char* msg, char *topic)
{
    cJSON* root = cJSON_Parse(msg);

    if (root == NULL)
    {
        return false;
    }
    cJSON *id, *sender, *time, *message;

    id = cJSON_GetObjectItem(root, "Id");
    time = cJSON_GetObjectItem(root, "Time");
    sender = cJSON_GetObjectItem(root, "Sender");
    message = cJSON_GetObjectItem(root, "Message");
    if (!id || !time || !sender || !message)
    {
        A_LOGW("Invalid Id/Time/Sender/Message json key\r\n");
        goto end;
    }
    
    if (!(cJSON_IsNumber(id)
        && cJSON_IsNumber(time)
        && cJSON_IsString(sender)
        && cJSON_IsObject(message)))
    {
        A_LOGW("Invalid Id/Time/Sender/Message json value\r\n");
        goto end;
    }

    A_LOGW("Rx ID -> '%d' from '%s', on topic %s\r\n", id->valueint, sender->valuestring, topic);
    A_LOGI("%s\r\n", msg);
    ttn_mqtt_process_msq_id(root, message, id->valueint, topic);
end:
    cJSON_Delete(root);
    return true;
}

void check_soundcard()
{
    char *shell_stdout = calloc(1024, 1);
    if (shell_stdout)
    {
        utils_run_shell_cmd(shell_stdout, 1024, true, "cat /proc/asound/cards");
        printf("%s", shell_stdout);
        if (strstr(shell_stdout, "USB-Audio"))
        {
            memset(shell_stdout, 0, 1024);
            utils_run_shell_cmd(shell_stdout, 1024, true, "cat /root/.asoundrc");
            printf("Current sound %s\r\n", shell_stdout);
            if (!strstr(shell_stdout, "defaults.pcm.!card 2"))
            {
                printf("Select usb sound card\r\n");
                FILE *f_in = NULL;
                // Get file size
                f_in = fopen("/root/.asoundrc", "w");
                if (!f_in)
                {
                    printf("Open audio sound failed\r\n");
                }
                else
                {
                    fprintf(f_in, "defaults.pcm.!card 2\n");
                    fprintf(f_in, "defaults.ctl.!card 2\n");
                    fclose(f_in);
                    printf("Reboot\r\n");
                    utils_run_shell_cmd(NULL, 0, true, "sync");
                    board_hw_sleep(5000);
                    utils_reboot();
                    board_hw_sleep(5000);
                }
            }
            else
            {
                printf("Default card is usb\r\n");
            }
        }
        else
        {
            memset(shell_stdout, 0, 1024);
            utils_run_shell_cmd(shell_stdout, 1024, true, "cat /root/.asoundrc");
            if (strstr(shell_stdout, "defaults.pcm.!card 2"))
            {
                utils_run_shell_cmd(shell_stdout, 1024, false, "rm -rf /root/.asoundrc");
                printf("Default card is audio codec\r\n");
                printf("Reboot\r\n");
                utils_run_shell_cmd(NULL, 0, true, "sync");
                board_hw_sleep(5000);
                utils_reboot();
                board_hw_sleep(5000);
            }
        }
        free(shell_stdout);
    }
}

static void wifi_scan_callback(wifi_info_t *info, int size)
{

}

static void send_command_restart_4g()
{
    // TODO
    // A_LOGW("Turn of 4G first\r\n");
    // char output[1024];
    // memset(output, 0, sizeof(output));
    // utils_run_shell_cmd(output, 1024, true, "timeout 5 echo \"AT+CFUN=0\r\n\" | tee /dev/ttyUSB2");
    // board_hw_sleep(1000);
    // A_LOGW("Restart 4G\r\n");
    // memset(output, 0, sizeof(output));
    // utils_run_shell_cmd(output, 1024, true, "timeout 10 echo \"AT+CFUN=1,1\r\n\" | tee /dev/ttyUSB2");
    // board_hw_sleep(15000);
}

void process_led(bool is_wifi_ok, bool is_4g_ok, bool is_lan_ok)
{
    uint32_t now = utils_sys_get_second();
    static uint32_t m_last = 0;
    if (m_last == now)
    {
        return;
    }

    m_last = now;
    host_data_layer_output_t *out = ip_io_get_gpio_output();
    if (audio_is_rx_streaming()) 
    {
        out->name.eth_led_b = LED_ON;
    }
    else
    {
        out->name.eth_led_b = LED_OFF;
    }

    if (ip_mqtt_get_state() == IP_MQTT_STATE_CONNECTED) 
    {
        if (is_wifi_ok || is_lan_ok) 
        {
            out->name.eth_led_r = LED_ON;
            out->name.lte_led_r = LED_OFF;
            out->name.lte_led_b = LED_OFF;
        } 
        else
        {
            out->name.lte_led_b = LED_ON;
            out->name.lte_led_r = LED_OFF;
            out->name.eth_led_r = LED_OFF;
        }
        // else if (is_4g_ok) 
        // {
        //     out->name.lte_led_b = LED_ON;
        //     out->name.lte_led_r = LED_OFF;
        //     out->name.eth_led_r = LED_OFF;
        // } 
        // else 
        // {
        //     out->name.eth_led_r = LED_OFF;
        //     out->name.lte_led_b = LED_OFF;
        // }
    } 
    else 
    {        // Server not connected
        if (is_wifi_ok || is_lan_ok)  
        {
            out->name.eth_led_r ^= 1;;
            out->name.lte_led_r = LED_OFF;
            out->name.lte_led_b = LED_OFF;
        } 
        else if (is_4g_ok) 
        {
            out->name.eth_led_r = LED_OFF;
            if (strlen(gsm_get_sim_ccid()) > 10) 
            {
                // SIM inserted nhưng không kn server
                out->name.lte_led_b ^= 1;
                out->name.lte_led_r = LED_OFF;
            } 
            else 
            {
                // SIM not inserted -> Led1 red/blue toggle
                out->name.lte_led_b ^= 1;
                out->name.lte_led_r ^= 1;
            }
        } 
        else 
        {
            //Không kết nối với mạng nào:
            out->name.eth_led_r = LED_OFF;
            if (strlen(gsm_get_sim_ccid()) > 10)  
            {
                // SIM inserted nhưng không có mạng -> nguyên nhân khác (vd activeNetwork = null, data disable...)
                // -> Led1 red toggle
                out->name.lte_led_b = LED_OFF;
                out->name.lte_led_r ^= 1;
            } 
            else 
            {
                // SIM not inserted -> Led1 red/blue toggle
                out->name.lte_led_b ^= 1;
                out->name.lte_led_r ^= 1;
            }
        }
    }
}

static void internet_ping()
{
    char shell_stdout[1024];
    static uint32_t m_last = 0;
    static uint32_t m_last_time_poll_if = 0;
    if (m_last == 0)
    {
        m_ping_if[0].tick = 50;
        m_last = utils_sys_get_second();
    }

    uint32_t now = utils_sys_get_second();
    uint32_t diff = now - m_last;
    host_data_layer_output_t *out = ip_io_get_gpio_output();

    /*
    * 0. Qui uoc
        LTE led  = led 1
        ETH led = led 2
        1. Neu server disconnect
        -> Dang dung 4G thi toggle led lte blue
        -> Dang dung ETH thi toggle led eth red
        -> Cac led khac giu nguyen trang thai
        2. Neu MQTT da connect
        ETH connect -> led 2 red on, led 1 red and blue off
        ETH disconnect -> led 2 red off, led 1 red and blue dont care

        4G connected -> led 1 blue on, led 1 red and led 2 red off
        4G disconnected -> led 1 blue off, led 1 red and led 2 dont care

        Streaming on  : led 2 blue on
        Streaming off : led 2 blue off
    */
    process_led(out->name.if_wifi, out->name.if_4g, out->name.if_eth);


    if (now - m_last_time_poll_if >= 10)
    {
        m_last_time_poll_if = now;
        if (!wifi_manager_is_scanning())
        {
            char *wifi_ip = wifi_get_ip();
            if (strlen(wifi_ip) > 5)
            {
                m_ping_if[IF_WIFI].is_disconnected = false;
                ip_io_set_if_wifi_flag(1);
            }
            else
            {
                m_ping_if[IF_WIFI].is_disconnected = true;
                ip_io_set_if_wifi_flag(0);
            }
            A_LOGI("WIFI %s\r\n", wifi_ip);
        }

        char *eth_ip = eth_get_ip();
        if (strlen(eth_ip) > 5)
        {
            m_ping_if[IF_LAN].is_disconnected = false;
            ip_io_set_if_lan_flag(1);
        }
        else
        {
            m_ping_if[IF_LAN].is_disconnected = true;
            ip_io_set_if_lan_flag(0);
        }
        A_LOGI("ETH %s\r\n", eth_ip);
    }


    for (int i = 0; i < 3; i++) 
    {
        // A_LOGV("IF%d, %d, %d\r\n", i, m_ping_if[i].delay_restarting, m_ping_if[i].tick);
        if (m_ping_if[i].delay_restarting > 0)
        {
            m_ping_if[i].delay_restarting -= diff;
            continue;
        }

        m_ping_if[i].tick += diff;
        if (m_ping_if[i].tick >= 60)
        {
            m_ping_if[i].tick = 0; 
            memset(shell_stdout, 0, sizeof(shell_stdout));
            utils_run_shell_cmd(shell_stdout, 1024, true, "timeout 5 ping -I %s 8.8.8.8", IF_DES[i]);
            A_LOGW("Ping %s, ret %s\r\n", IF_DES[i], shell_stdout);
            if (strlen(shell_stdout) > 10 && strstr(shell_stdout, "icmp_seq=") && strstr(shell_stdout, "time="))
            {
                m_ping_if[i].is_error = false; 
                m_ping_if[i].delay_restarting = 0; 
                m_4g_up_but_sim_error = false;
                ip_io_set_if_4g_flag(1);
            }
            else
            {
                // TODO restart IF
                m_ping_if[i].delay_restarting = 60; 
                if (m_4g_up_but_sim_error)
                {
                    ip_io_set_if_4g_toggle();
                }
                else
                {
                    ip_io_set_if_4g_flag(0);
                }

                if (!m_ping_if[i].is_error)
                {
                    A_LOGE("IF %s error\r\n", IF_DES[i]);
                    if (i == 0)
                    {
                        A_LOGE("Reset 4G\r\n");
                        log_file_write("Reset 4G\r\n");
                        ip_mqtt_dbg("Reset 4G");
                        send_command_restart_4g();
                        m_gsm_state = GSM_STATE_INIT;
                        m_gsm_fsm_counter = 0;
                    }
                }
                m_ping_if[i].is_error = true; 
            }
        }
    }

    m_last = utils_sys_get_second();
    return;
}


static void on_mqtt_msq(char *topic, char *msg)
{
    atth_mqtt_parse(msg, topic);
}

int main(int argc, char* argv[])
{
    pthread_mutex_init(&m_mutex_dbg, NULL);
    ip_wdt_init();
    ip_mqtt_init(on_mqtt_msq);

#if MIN_OVER_SOCKET
    pthread_mutex_init(&m_mutex_python, NULL);
#endif



    pthread_mutex_init(&m_mutex_log_file, NULL);
    
    // Init debug module
    ip_dbg_init(utils_sys_get_second, ip_dbg_lock);
    ip_dbg_register_callback_print(ip_dbg_output_cb);
    
    ip_io_init_hardware();

    check_soundcard();

    ip_dbg_set_level(DBG_LVL_ERROR);
    
    ip_flk_start();


    // Load all configuration
    ip_flk_load_configuration();
    

    if (argc == 1)
    {
        // board_hw_sleep(15000);      // Cho OS on dinh
    }


    printf("SYSTEM %s\r\n", ip_flk_get_4g_imei());
    if (1)
    {
        ip_dbg_register_callback_print(debug_to_tty);
    }

    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    export_gpio();
	
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pulseaudio --start");
    // LTE prefer
    // uqmi_setting_prefer_lte();


    // printf("DBG : %s, %d\r\n", __FILE__, __LINE__);
    // Set default vol
    int volume = ip_flk_get_volume(0);
    if (volume == 0)
    {
        audio_codec_mute(1);
    }
    // todo check volume down stream and volume up stream
    ip_decoder_change_codec_vol(volume);

    // utils_run_shell_cmd(NULL, 0, true, "rm -rf ./../*.c");

    // kill all ffmpeg
    // utils_run_shell_cmd(NULL, 0, true, "timeout 5 ip link set wwan0 up");
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffmpeg");
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffplay");
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f aplay");
    audio_detect_card();
    utils_run_shell_cmd(NULL, 0, true, "amixer set 'DAC' -M %d%%", 100);
    board_hw_sleep(3000);
    // TODO
    pthread_create(&p_tid_ping, NULL, &ip_io_thread, NULL);
    pthread_create(&p_tid_mqtt, NULL, &ip_mqtt_thread, NULL);
#if MIN_OVER_SOCKET
    pthread_create(&p_tid_socket, NULL, &socket_thread, NULL);
#endif
    pthread_create(&p_tid_gsm, NULL, &gsm_thread, NULL);
    pthread_create(&p_tid_dtmf, NULL, &ip_io_dtmf_poll, NULL);


    // pthread_create(&p_audio_tid, NULL, &audio_ffmpeg_thread, NULL);

    // Create wdt thread
    ip_wdt_start();
    log_file_init();
    log_file_write("Application started\r\n");
    pthread_join(p_tid_mqtt, NULL);
    // pthread_join(p_tid_socket, NULL);
    pthread_join(p_tid_gsm, NULL);

    pthread_join(p_tid_ping, NULL);
    pthread_join(p_tid_dtmf, NULL);

    
    // never happen
    while (1)
    {
        board_hw_sleep(1000);
    }
}
