#ifndef IP_MQTT_H
#define IP_MQTT_H

#include "stdint.h"
#include "stdbool.h"

typedef enum
{
    IP_MQTT_STATE_INIT,
    IP_MQTT_STATE_CONNECTING,
    IP_MQTT_STATE_CONNECTED,
    IP_MQTT_STATE_DISCONNECTED,
    IP_MQTT_STATE_NEED_DESTROY
} ip_mqtt_state_t;

typedef struct
{
    char *payload;
    char *topic;
} ip_mqtt_event_data_t;
typedef void (*ip_mqtt_event_cb_t)(char *topic, char *data);

void ip_mqtt_init(ip_mqtt_event_cb_t callback);

void* ip_mqtt_thread(void* arg);
void ip_mqtt_audio_default_auto_reset_stream(int timeout);
int ip_mqtt_get_auto_stop_stream_timeout(void);
int ip_mqtt_get_state(void);
void ip_mqtt_set_fsm_state(ip_mqtt_state_t state);
void ip_mqtt_dbg(const char *format, ...);
void ip_mqtt_heartbeat_soon(int delay_s);
void ip_mqtt_reply_cfg(char *msg_id, bool is_success, char *msg);
/**
 * @brief           Send raw message to broker
 * @param[in]       topic topic
 * @param[in]       msg Data
 * @retval          Message id, -1 on error
 */
int ip_mqtt_send_raw(char *topic, char *payload);
void ip_mqtt_resub_all_master(void);
void ip_mqtt_try_new_broker(void *brk);

#endif //IP_MQTT_H