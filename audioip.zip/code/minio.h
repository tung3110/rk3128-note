#ifndef MINIO_H
#define MINIO_H

void minio_upload_log(char *object_name);

#endif //