#include "audio.h"
#include "utils.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stream_info.h"
#include "utils.h"
#include "pthread.h"
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include "ip_dbg.h"
#include <errno.h>
#include "ip_flk.h"
#include <signal.h>
#include "board_hw.h"
#include "ip_mqtt.h"
#include "log_file.h"

#define FFMPEG_BUFFER_SIZE  (4096)
#define MONITOR_ENABLE 0

static volatile int m_delay_for_new_stream = 0, m_auto_stop_stream = 0, m_auto_update_ntp = 0;
static bool m_allow_audio_thread_run = true;
static pthread_t p_audio_rx_tid, p_audio_tx_tid;
static bool create_rx_audio_thread(char *url);
static char ffmpeg_cmd_buffer[1024];
static char m_session[64];
static bool m_encoder_started = false;
static int m_ffmpeg_up_pid = -1;
static char ffmpeg_up_cmd[256];
static char m_upstream_url[256];
static int m_ffmpeg_down_pid = -1;
static bool ok_tx_stream = false;
static uint32_t m_total_stream_time_in_one_day = 0;

typedef struct
{
    int out_channel;
    int in_channel;
    int count;
    char *card;
} audio_card_t;


static stream_monitor_info_t m_stream_monitor = 
{
    .mute = -1,
};

static audio_card_t m_card =
{
    .out_channel = 1,
    .in_channel = 1,
    .count = 1,
    .card = "...",
};

void audio_detect_card()
{
}


void audio_classD_mute(int is_mute)
{

}

static void alsa_set_rx_stream_volume(int vol)
{
    if (vol > 100)
        vol = 100;
    if (vol < 0)
        vol = 0;
    //utils_run_shell_cmd(NULL, 0, true, "amixer set 'Line Out' -M %d%%", vol);
    if (m_card.count != 1)
    {
        utils_run_shell_cmd(NULL, 0, true, "amixer -c 1 set 'Headphone' -M %d%%", vol);
    }
    // utils_run_shell_cmd(NULL, 0, true, "amixer set 'PCM' -M %d%%", vol);
    //utils_run_shell_cmd(NULL, 0, true, "amixer set 'Master' -M %d%%", vol);
	utils_run_shell_cmd(NULL, 0, true, "timeout 3 pulseaudio --start");
    utils_run_shell_cmd(NULL, 0, true, "amixer -q -D pulse sset Master %d%%", vol);

}


void ip_decoder_change_codec_vol(int volume)
{
    alsa_set_rx_stream_volume(volume);
}

bool audio_is_mute()
{
    return m_stream_monitor.mute == 1;
}

void audio_codec_mute(int is_mute)
{
    if (m_stream_monitor.mute == is_mute)
        return;
    m_stream_monitor.mute = is_mute;
    

    audio_classD_mute(is_mute);
}

void audio_reset_stream_monitor_data(void)
{
    m_stream_monitor.state = STREAM_IDLE;
    m_stream_monitor.stream_time = 0;
    m_stream_monitor.downloaded = 0;
}

static bool is_audio_rx_thread_alive(void)
{
    int is_alive = false;
    int ret;
    if (p_audio_rx_tid == 0)
    {
       goto end;
    } 
    
    ret = pthread_kill(p_audio_rx_tid, 0);
    if (ret == 0)
    {
        is_alive = true;
    }
end:
    return is_alive;
}

void audio_kill_audio_thread(void)
{
    A_LOGI("Kill audio %d PID\r\n", m_ffmpeg_up_pid);
    m_allow_audio_thread_run = false;
    int timeout = 20;

    while (is_audio_rx_thread_alive() && timeout > 0)
    {
        timeout--;
        board_hw_sleep(50);
    }
    board_hw_sleep(1000);
    if (m_ffmpeg_up_pid > 0)
    {
        utils_run_shell_cmd(NULL, 0, true, "kill %ld", m_ffmpeg_up_pid);
    }
    p_audio_rx_tid = 0;
}


bool audio_is_allow_relay_run()
{
    return (m_stream_monitor.state == STREAM_RUNNING 
            || m_stream_monitor.state == STREAM_PREPARE 
            || ip_flk_get_working_mode() == OPERATION_MODE_LINE
            || ip_flk_get_working_mode() == OPERATION_MODE_MIC
            || ip_flk_get_working_mode() == OPERATION_MODE_FM
            || (m_delay_for_new_stream > 0));
}

static int get_pid_ffmpeg_upstream(char *buffer)
{
    int found_pid = -1;
    char *pid_ptr = buffer;
    char pid_str[32];
    memset(pid_str, 0, sizeof(pid_str));
    while ((*pid_ptr < '0' || *pid_ptr > '9') && *pid_ptr)
    {
        pid_ptr++;
    }
    if (*pid_ptr)
    {
        char *tmp = pid_str;
        while ((*pid_ptr >= '0' && *pid_ptr <= '9') && *pid_ptr)
        {
            *tmp = *pid_ptr;
            pid_ptr++;
            tmp++;
        }
    }
    found_pid = atoi(pid_str);
    return found_pid;
}

uint32_t audio_get_stream_time_in_day()
{
    return m_total_stream_time_in_one_day;
}

void *audio_play_thread(void* arg)
{
    utils_run_shell_cmd(NULL, 0, true, "amixer set 'DAC' -M %d%%", 100);
    m_stream_monitor.state = STREAM_RUNNING;
    if (!m_stream_monitor.mute)
    {
        ip_decoder_change_codec_vol(ip_flk_get_volume(0));
    }
    else
    {
        ip_decoder_change_codec_vol(0);
    }
    // Neu khong ngu 5s thi khi load icecast se thay load roi dung
    // Do con server icecast no the
    board_hw_sleep(3000);

    FILE *ffmpeg_sub = NULL, *aplay_sub = NULL;
    int timeout_close_process = 5;
    pid_t subpid;
    int status = -1;
    int len;
    static char buffer_ffmpeg[FFMPEG_BUFFER_SIZE];
    char *url = (char*)arg;
    int poll_timeout_counter = 0;
    char *tmpFind="=";
    char *tmpSrt="http";
    if (m_card.count == 1)
    {
        char *keyValue = strstr(url,tmpFind);
        char *keySrt = strstr(url,tmpSrt);
        if(keyValue)
        {
           sprintf(ffmpeg_cmd_buffer, "ffplay -af volume=2.0 -i -fflags nobuffer -max_delay 0 -hide_banner -loglevel error 'webrtc://live-prod.truyenthanhso.vn/rtc/v1/whep/?app=live&stream%s' -nodisp", keyValue);
        }
        else if(!keySrt)
        {
           char *keyTmp = strstr(url,"live");
           sprintf(ffmpeg_cmd_buffer, "ffplay -af volume=2.0 -rw_timeout 20000000 -fflags nobuffer -max_delay 200000 -flags low_delay -hide_banner -loglevel error 'srt://42.96.43.204:30000?streamid=#!::r=%s,m=request' -nodisp", keyTmp);
        }
        else sprintf(ffmpeg_cmd_buffer, "ffplay -af volume=2.0 -rw_timeout 20000000 -fflags nobuffer -max_delay 200000 -flags low_delay -hide_banner -loglevel error %s -nodisp", url);
    }
    else
    {
        sprintf(ffmpeg_cmd_buffer, "ffmpeg -af volume=2.0 -re -y -rw_timeout 5000000 -hide_banner -loglevel error -i %s -vn -ac 2 -f alsa hw:1,0", url);
    }

    A_LOGI("audio cmd : %s\r\n", ffmpeg_cmd_buffer);
    log_file_write("Run ffmpeg cmd %s\r\n", ffmpeg_cmd_buffer);

    utils_run_shell_cmd(NULL, 0, false, "%s &", ffmpeg_cmd_buffer);

    audio_reset_stream_monitor_data();
    int monitor_ffmpeg_interval = 0;
    size_t stream_on = time(NULL);

    size_t monitor_downloaded_kb = time(NULL);
    m_stream_monitor.state = STREAM_RUNNING;

    size_t m_last_stream_time = utils_sys_get_second();
    ip_mqtt_heartbeat_soon(2);
    ip_decoder_change_codec_vol(ip_flk_get_volume(0));
    while (m_allow_audio_thread_run)
    {    
        if (monitor_ffmpeg_interval++ > 10)
        {
            monitor_ffmpeg_interval = 0;
            static char ps_out[2048];
            static char new_ffmpeg_cmd[1024+5];
            memset(ps_out, 0, sizeof(ps_out));
            memset(ps_out, 0, sizeof(new_ffmpeg_cmd));
            new_ffmpeg_cmd[0] = '[';
            new_ffmpeg_cmd[1] = ffmpeg_cmd_buffer[0];
            new_ffmpeg_cmd[2] = ']';
            sprintf(new_ffmpeg_cmd+3, "%s", ffmpeg_cmd_buffer+1);

            utils_run_shell_cmd(ps_out, 1024, true, "timeout 3 ps aux | grep \"%s\"", new_ffmpeg_cmd);
            char *p = strstr(ps_out, ps_out);
            // char *p = strstr(ps_out, "ffmpeg -re -y -hide_banner -loglevel error -i");

            if (!p)
            {
                A_LOGI("[0] RX Stream bad\r\n");
                log_file_write("Stream bad\r\n");
                m_allow_audio_thread_run = false;
                m_delay_for_new_stream = 0;
                ip_mqtt_dbg("Rx stream %s bad", m_stream_monitor.url);
            }
            else
            {
                p += strlen(ffmpeg_cmd_buffer);
                p = strstr(ps_out, ps_out);
                if (!p)
                {
                    A_LOGI("[1] Stream bad\r\n");
                    log_file_write("Stream bad\r\n");
                    m_session[0] = 0;
                }
                else
                {
                    char *p = strstr(ps_out, "SLl+");
                    m_ffmpeg_up_pid = get_pid_ffmpeg_upstream(ps_out);
                    A_LOGI("[1] Stream link OK, pid %d\r\n", m_ffmpeg_up_pid);
                    size_t now = utils_sys_get_second();
                    m_total_stream_time_in_one_day += (now - m_last_stream_time);
                    m_last_stream_time = now;
                }
            }
            // A_LOGI("Output\r\n%s\r\n", ps_out);
        }
        board_hw_sleep(500);
    }
    A_LOGI("Close aplay_sub\r\n");
    if (aplay_sub) fclose(aplay_sub);
    A_LOGI("Close ffmpeg\r\n");
    aplay_sub = NULL;

close:
    A_LOGW("Exit audio thread, pid %d\r\n", m_ffmpeg_up_pid);
    // utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffmpeg");
    if (m_ffmpeg_up_pid > 0)
    {
        // utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffmpeg");
        // utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f aplay");
        utils_run_shell_cmd(NULL, 0, true, "timeout 3 kill %ld", m_ffmpeg_up_pid);
        m_ffmpeg_up_pid = -1;
    }
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffplay");
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f ffmpeg");
    utils_run_shell_cmd(NULL, 0, true, "timeout 3 pkill -9 -f aplay");
end:
    audio_reset_stream_monitor_data();
    m_stream_monitor.url[0] = 0;

    p_audio_rx_tid = 0;
    m_allow_audio_thread_run = true;
    ip_mqtt_heartbeat_soon(2);
    pthread_exit(NULL);
}

int audio_get_rx_stream_state()
{
    return m_stream_monitor.state;
}

bool audio_is_rx_streaming(void)
{
    return m_stream_monitor.state == STREAM_RUNNING;
}

char *ip_audio_get_last_rx_stream_url()
{
    if (m_stream_monitor.state == STREAM_RUNNING)
        return m_stream_monitor.url;
    return "";
}

void audio_default_auto_reset_stream(uint8_t time)
{
    m_auto_stop_stream = time;
}

void audio_start_rx_streaming(char *url, char *session)
{
    if (url == NULL || (strstr(url, "http://") == NULL && strstr(url, "https://") == NULL))
    {
       // return;
    }

    if (strcmp(url, m_stream_monitor.url) == 0)
    {
        A_LOGI("Same URL\r\n");
        m_delay_for_new_stream = 60;
        m_auto_stop_stream = AUDIO_AUTO_STOP_STREAM;
        return;
    }

    if (is_audio_rx_thread_alive())
    {
        audio_kill_audio_thread();
    }
    
    A_LOGI("Previous URL: %s, new %s, session %s\r\n", m_stream_monitor.url, url, session);
    m_delay_for_new_stream = 60;
    sprintf(m_stream_monitor.url, "%s", url);
    sprintf(m_session, "%s", session);
    m_auto_stop_stream = AUDIO_AUTO_STOP_STREAM;
    create_rx_audio_thread(m_stream_monitor.url);
}


void audio_stop_rx_streaming()
{
    if (m_stream_monitor.state != STREAM_RUNNING)
    {
        return;
    }
    if (is_audio_rx_thread_alive())
    {
        audio_kill_audio_thread();
    }
    m_delay_for_new_stream = 0;
    m_session[0] = 0;
}


static bool create_rx_audio_thread(char *url)
{
    if (is_audio_rx_thread_alive())
    {
        A_LOGW("Audio thread already running\r\n");
        return false;
    }
    int err = pthread_create(&p_audio_rx_tid, 
                            NULL, 
                            &audio_play_thread, 
                            url);
    if (err)
    {
        A_LOGW("Create audio thread err %d\r\n", err);
    }

    if (ip_flk_get_volume(0))
    {
        audio_codec_mute(0);
    }
    return true;
}


void audio_timeout_1s_poll()
{
    if (m_delay_for_new_stream > 0)
    {
        m_delay_for_new_stream--;
    }

    if (m_auto_stop_stream > 0)
    {
        m_auto_stop_stream--;
        if (m_auto_stop_stream == 0 && is_audio_rx_thread_alive())
        {
            ip_mqtt_dbg("Auto stop stream");
            audio_stop_rx_streaming();
        }
    }

    if (m_auto_update_ntp >= 1800)
    {
        m_auto_update_ntp = 0;
        utils_run_shell_cmd(NULL, 0, false, "timeout 15 ntpdate pool.ntp.org");
    }
}

char *ip_audio_get_last_stream_session()
{
    return m_session;
}


static void *audio_up_thread()
{
    A_LOGW("Stream up : %s\r\n", ffmpeg_up_cmd);
    static char shell_up_out[2048];
    utils_run_shell_cmd(NULL, 0, false, "%s", ffmpeg_up_cmd);
    board_hw_sleep(5000);

    char *tmp_up_cmd = "0 -af aresample=async=1";
    
    static char new_ffmpeg_cmd[1024+5];

    while (1)
    {

        memset(shell_up_out, 0, sizeof(shell_up_out));
        new_ffmpeg_cmd[0] = '[';
        new_ffmpeg_cmd[1] = ffmpeg_up_cmd[0];
        new_ffmpeg_cmd[2] = ']';
        sprintf(new_ffmpeg_cmd+3, "%s", ffmpeg_up_cmd+1);

        utils_run_shell_cmd(shell_up_out, 1024, true, "timeout 3 ps aux | grep \"%s\"", new_ffmpeg_cmd);
        char *p = strstr(shell_up_out, tmp_up_cmd);
        if (!p)
        {
            A_LOGW("[0] Stream up bad, out \r\n%s\r\nTarget %s\r\n", shell_up_out, tmp_up_cmd);
            ok_tx_stream = false;
        }
        else
        {
            p = shell_up_out;
            if (!p)
            {
                A_LOGI("[1] Stream up : bad\r\n");
                ok_tx_stream = false;
            }
            else
            {
                m_ffmpeg_down_pid = get_pid_ffmpeg_upstream(shell_up_out);
                ok_tx_stream = true;
                A_LOGI("[1] Stream up OK, pid %d\r\n", m_ffmpeg_down_pid);
            }
        }

        if (!ok_tx_stream)
        {
            ip_mqtt_dbg("TX stream %s bad\r\n", m_upstream_url);
            utils_run_shell_cmd(NULL, 0, false, "%s", ffmpeg_up_cmd);
        }
        board_hw_sleep(10000);
    }
}

char *audio_get_up_stream_url()
{
    return m_upstream_url;
}

void ip_encoder_upstream_start(char *host, int port, char *src, char *pass, char *mount)
{
    sprintf(m_upstream_url, "http://%s:%d/%s", host, port, mount);
    int card_idx = m_card.count - 1;
    
    sprintf(ffmpeg_up_cmd, "ffmpeg -re -y -loglevel error -f alsa -ac 1 -i hw:%d,0 -af aresample=async=1 -ac 1 -acodec libopus -b:a 48k -f opus -content_type \"audio/ogg;codec=opus\" -map_metadata -1 icecast://%s:%s@%s:%d/%s &",
                        card_idx, src, pass, host, port, mount);

    A_LOGW("Start audio up thread\r\n%s\r\n", ffmpeg_up_cmd);
    pthread_create(&p_audio_tx_tid, 
                            NULL, 
                            audio_up_thread, 
                            ffmpeg_up_cmd);
}

bool is_ip_encoder_streaming()
{
    return ok_tx_stream;
}
