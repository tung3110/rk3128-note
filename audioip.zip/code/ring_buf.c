#include "ring_buf.h"

uint32_t ring_buf_get_free(ring_buf_t *buf)
{
    uint32_t size;
    if (!buf)
    {
        return 0;
    }

    if (buf->wr_idx == buf->rd_idx)
    {
        size = buf->size;
    }
    else if (buf->rd_idx > buf->wr_idx)
    {
        size = buf->rd_idx - buf->wr_idx;
    }
    else
    {
        size = buf->size - buf->wr_idx + buf->rd_idx;
    }
    
    return size - 1;
}

uint32_t ring_buf_get_size_to_read(ring_buf_t *buf)
{
    uint32_t size;
    if (buf->wr_idx == buf->rd_idx) 
    {
        size = 0;
    } 
    else if (buf->wr_idx > buf->rd_idx) 
    {
        size = (buf->wr_idx - buf->rd_idx);
    } 
    else 
    {
        size = (buf->size - buf->rd_idx  + buf->wr_idx);
    }
    return size;
}

bool ring_buf_write(ring_buf_t *buf, ring_buf_data_t *msg)
{   
    if (ring_buf_get_free(buf) == 0 
        || !msg 
        ||! msg->len)
    {
        return false;
    }

    buf->buff[buf->wr_idx].len = msg->len;
#if USE_STATIC_BUFFER
    memcpy(buf->buff[buf->wr_idx].data, msg->data, msg->len);
#else
    buf->buff[buf->wr_idx].data = msg->data;
    buf->buff[buf->wr_idx].topic = msg->topic;
    buf->buff[buf->wr_idx].need_free = msg->need_free; 
#endif
    buf->wr_idx++;

    if (buf->wr_idx >= buf->size)
        buf->wr_idx = 0;

    return true;
}

bool ring_buf_read(ring_buf_t *buf, ring_buf_data_t * msg)
{
    if (ring_buf_get_size_to_read(buf) == 0 
        || !msg)
    {
        return false;
    }

    uint32_t idx = buf->rd_idx;
    
    msg->len = buf->buff[buf->rd_idx].len;
#if USE_STATIC_BUFFER
    memcpy(msg->data, buf->buff[buf->rd_idx].data, msg->len);
#else
    msg->data = buf->buff[buf->rd_idx].data;
    msg->topic = buf->buff[buf->rd_idx].topic;
    msg->need_free = buf->buff[buf->rd_idx].need_free;  
#endif
    buf->rd_idx++;
    
    if (buf->rd_idx >= buf->size)
        buf->rd_idx = 0;

    return true;
}

void ring_buf_skip(ring_buf_t *buf, uint32_t skip_cnt)
{
    uint32_t size = ring_buf_get_size_to_read(buf);
    
    if (skip_cnt >= size)
        skip_cnt = size;
    
    for (uint32_t i = 0; i < skip_cnt; i++)
    {
#if USE_STATIC_BUFFER == 0
        if (buf->buff[buf->rd_idx].need_free)
        {
            if (buf->buff[buf->rd_idx].data) free(buf->buff[buf->rd_idx].data);
            if (buf->buff[buf->rd_idx].topic) free(buf->buff[buf->rd_idx].topic);
        }
#endif
        buf->rd_idx++;   
        if (buf->rd_idx >= buf->size)
            buf->rd_idx = 0;
    }
}