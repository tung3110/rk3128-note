#include "wifi_manager.h"
#include "utils.h"
#include "ip_dbg.h"
#include "string.h"
#include "stdio.h"

static bool m_is_scanning = false;
static wifi_info_t m_wifi_list[MAX_WIFI_COUNT];
static const char *SCAN_WIFI_CMD = "timeout 5 iw dev wlan0 scan | grep -E 'SSID:|signal:' | awk 'NR%%2{ssid=$2; next} {print ssid \", \" $2}'";
static const char *WIFI_IP_CMD = "timeout 3 ip -4 addr show wlan0 | grep -oP '(?<=inet\\s)\\d+(\\.\\d+){3}'";
static bool m_connected = false;

static void parse_wifi_data(const char *data, wifi_info_t m_wifi_list[], int *count, int max_count) 
{
    char buffer[256];
    const char *ptr = data;
    int index = 0;

    while (index < max_count && sscanf(ptr, "%f, %99[^\n]", &m_wifi_list[index].rssi, m_wifi_list[index].ssid) == 2) 
    {
        index++;
        ptr = strchr(ptr, '\n');
        if (ptr == NULL) break;
        ptr++;
    }
    *count = index;
}

bool wifi_manager_is_scanning(void)
{
    return m_is_scanning;
}

void wifi_manager_scan(on_wifi_scan_callback callback)
{
    if (m_is_scanning || callback == NULL)
    {
        A_LOGI("Already scanning...\r\n");
        return;
    }
    m_is_scanning = true;
    static char output_buffer[2048];
    memset(output_buffer, 0, sizeof(output_buffer));
    memset(m_wifi_list, 0, sizeof(m_wifi_list));

    // timeout 5 iw dev wlan0 scan | grep -E 'SSID:|signal:' | awk 'NR%2{ssid=$2; next} {print ssid ", " $2}'
    utils_run_shell_cmd(output_buffer, sizeof(output_buffer), true, SCAN_WIFI_CMD);
    int count = 0;

    parse_wifi_data(output_buffer, m_wifi_list, &count, MAX_WIFI_COUNT);
    if (callback) callback(m_wifi_list, count);

    m_is_scanning = false;
}

bool wifi_manager_connect(char *ssid, char *password)
{
    if (m_is_scanning)
    {
        return false;
    }
    static char output_buffer[512];
    memset(output_buffer, 0, sizeof(output_buffer));
    utils_run_shell_cmd(output_buffer, sizeof(output_buffer), true, "timeout 10 nmcli device wifi connect \"%s\" password \"%s\"", ssid, password);
    return strstr(output_buffer, "successfully activated with");
}

bool wifi_is_connected()
{
    return m_connected;
}

bool wifi_get_name_and_rssi(char **name, int *rssi)
{
    char output_buffer[256];
    static char ssid[64];
    memset(output_buffer, 0, sizeof(output_buffer));
    utils_run_shell_cmd(output_buffer, sizeof(output_buffer), true, "timeout 3 nmcli -f IN-USE,SSID,SIGNAL dev wifi | grep '*'");
    if (strlen(output_buffer) > 5)
    {
        memset(ssid, 0, sizeof(ssid));
        if (sscanf(output_buffer, "* %s %d", ssid, rssi) == 2) 
        {
            *name = ssid;
            return true;
        } 
        else 
        {
            printf("Failed to parse the output\n");
        }
        return true;
    }
    return false;
}

char *wifi_get_ip(void)
{
    static char output_buffer[256];
    memset(output_buffer, 0, sizeof(output_buffer));
    utils_run_shell_cmd(output_buffer, sizeof(output_buffer), true, WIFI_IP_CMD);
    if (strlen(output_buffer) >= 8)
    {
        m_connected = true;
        char *p = strstr(output_buffer, "\n");
        if (p) *p = 0;
    }
    else
    {
        m_connected = false;
    }
    return output_buffer;
}