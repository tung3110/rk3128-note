#include "ip_wdt.h"
#include <board_hw.h>
#include <pthread.h>
#include <stdio.h>
#include "utils.h"

static int m_wdt_value = WDT_THREAD_ALL;
static pthread_mutex_t m_mutex_wdt;
static pthread_t p_wdt_tid;
static void *wdt_thread(void* arg);

void ip_wdt_init(void)
{
    pthread_mutex_init(&m_mutex_wdt, NULL);
    pthread_create(&p_wdt_tid, NULL, &wdt_thread, NULL);
}

void ip_wdt_feed(int thread_id)
{
    pthread_mutex_lock(&m_mutex_wdt);
    m_wdt_value |= (1 << thread_id);
    pthread_mutex_unlock(&m_mutex_wdt);
}

void ip_wdt_start()
{
    pthread_join(p_wdt_tid, NULL);
}

static void *wdt_thread(void* arg)
{
    board_hw_sleep(5000);
    while (1)
    {
        int value = 0;
        pthread_mutex_lock(&m_mutex_wdt);

        value = m_wdt_value;
        m_wdt_value = 0;

        pthread_mutex_unlock(&m_mutex_wdt);

        if (0 == (value & WDT_THREAD_ALL))
        {
            if (!(value & (1 << WDT_THREAD_GSM)))
            {
                printf("4G thread dead\r\n");
            }

            if (!(value & (1 << WDT_THREAD_MQTT)))
            {
                printf("MQTT thread dead\r\n");
            }

            if (!(value & (1 << WDT_THREAD_TCP)))
            {
                printf("TCP thread dead\r\n");
            }
            utils_reboot();
            board_hw_sleep(5000);
        }
        else
        {
            printf("All task alive\r\n");
        }

        board_hw_sleep(20000);
    }
    pthread_exit(NULL);
}
