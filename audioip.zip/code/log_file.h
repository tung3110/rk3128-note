#ifndef LOG_FILE_H
#define LOG_FILE_H

#define LOG_FILE_RING_BUFFER_SIZE (1024 * 10)
#define LOG_FILE_WRITE_INTERVAL_MS 5000 // ms

void log_file_write(const char *fmt, ...);
void log_file_init(void);
void log_file_flush();

#endif // LOG_FILE_H