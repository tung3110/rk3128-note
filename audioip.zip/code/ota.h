#ifndef OTA_H
#define OTA_H

#include <stdint.h>


#define MAX_OTA_FILE_SIZE (5000000)
#define FIRMWARE_SIGNATURE "RK3"

typedef union
{
    struct
    {
        char header[3];                 // Image header
        char fw_version[3];       // Firmware version
        char hw_version[3];       // Hardware version
        uint32_t size;         // fw size =  image_size + 16 byte md5 or 4 byte CRC32, excluded header
        uint8_t release_year;           // From 2000
        uint8_t release_month;          // 1 to 12
        uint8_t release_date;           // 0 to 31
    } __attribute__((packed)) name;
    uint8_t raw[16];
}  ota_image_header_t;


typedef struct
{
    char url[256];
    char username[128];
    char password[128];
} ota_url_t;

void ota_start(char *url, char *username, char *password);

#endif // OTA_H
