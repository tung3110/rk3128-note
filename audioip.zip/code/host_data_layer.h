#ifndef HOST_DATA_LAYER_H
#define HOST_DATA_LAYER_H

#include <stdint.h>

typedef enum
{
    HOST_POWER_STARTING,
    HOST_POWER_UP,
    HOST_POWER_PULSE_PWR_KEY,
    HOST_POWER_RUNNING,
    HOST_POWER_WAIT_FOR_VIN,
    HOST_POWER_DOWN,
    HOST_POWER_FLASH_MODE
} host_power_state_t;

typedef union
{
    struct
    {
        uint32_t dtmf1                              : 1;
        uint32_t dtmf2                              : 1;
        uint32_t na                                 : 4;
        uint32_t speaker_on_off                     : 1;
        uint32_t relay1                             : 1;
        uint32_t relay2                             : 1;
        uint32_t fan                                : 1;
        uint32_t mic_line_sw                        : 1;
        uint32_t meeting_led                        : 1;
        uint32_t switch_in                          : 1;
        uint32_t switch_out                         : 1;
        uint32_t lte_led_r                          : 1;
        uint32_t lte_led_b                          : 1;
        uint32_t eth_led_r                          : 1;
        uint32_t eth_led_b                          : 1;
        uint32_t pa                                 : 1;
        uint32_t sw_mic                             : 1;
        uint32_t if_4g                              : 1;
        uint32_t if_wifi                            : 1;
        uint32_t if_eth                             : 1;
        uint32_t operation_mode                     : 3;
        uint32_t nextion_enable                     : 1;
        uint32_t sw_mic_in_from_mic_line_or_hp      : 1;        // config_mic
        uint32_t sw_line_out_in_from_mic_line_or_hp : 1;        // con hp mach ATTH 7 inch
        uint32_t sw_lineout_enable                  : 1;        // en_hph_out
        uint32_t sw_pa_out_from_mic_line_or_hp      : 1;        // config hp mach node PA
        uint32_t class_d                            : 1;
    } __attribute__((packed)) name;
    uint32_t value;
} __attribute__((packed)) host_data_layer_output_t;

typedef union
{
    struct
    {
        uint8_t input0         : 1;
        uint8_t input1         : 1;
        uint8_t input2         : 1;
        uint8_t input3         : 1;
        uint8_t input4         : 1;        // bit nay khong dung nhung de tuong thich nguoc voi ATTH -> van them vao
        uint8_t button_on_air  : 1;
        uint8_t reserve        : 2;
    } __attribute__((packed)) name;
    uint8_t value;
} __attribute__((packed)) host_data_layer_input_t;


typedef union
{
    struct
    {
        uint8_t d_vol_err         : 1;
        uint8_t class_d           : 4;
        uint8_t heartbeat_err     : 1;
        uint8_t reserve           : 2;
    } __attribute__((packed)) name;
    uint8_t value;
} __attribute__((packed)) host_data_layer_debug_flag_t;

typedef union
{
    struct
    {
        uint8_t s1_in1          : 1;
        uint8_t s1_in2          : 1;
        uint8_t s2_in1          : 1;
        uint8_t s2_in2          : 1;
        uint8_t s3_in1          : 1;
        uint8_t s3_in2          : 1;
        uint8_t s4_in1          : 1;
        uint8_t s4_in2          : 1;
    } __attribute__((packed)) name;
    uint8_t value;
} __attribute__((packed))  extend_t;

typedef struct
{
    uint8_t screen_id;
    uint16_t vin_mv;
    uint16_t vbus_24v_mv;
    uint8_t headphone;
    host_data_layer_input_t input;
    host_data_layer_output_t output;
    uint8_t hardware_version[3];
    uint8_t firmware_version[3];
    uint8_t mic;        // dont care
    uint8_t line_in;    // dont care
    uint16_t v3v8_mv;    // dont care
    host_data_layer_debug_flag_t error_flag;
    uint8_t is_all_in_one;
    extend_t extend;
} __attribute__((packed)) host_data_layer_ping_msg_t;

typedef struct
{
    uint8_t mode;		// ref Audio_Operation_Mode_t
    uint8_t vol;
    uint32_t snr;
    uint32_t rssi;
    uint32_t dbm;
    float gps_lat;
    float gps_long;
    uint32_t freq;
    uint8_t fw_version;
    uint8_t hw_version;
} __attribute__((packed)) fm_to_host_frame_t;

 
typedef struct
{
    uint8_t mode;		// ref Audio_Operation_Mode_t
    uint8_t server_state;	// MQTT_DISCONNECTED = 0, MQTT_CONNECTING = 1, MQTT_CONNECTED = 2
    uint8_t interface;	// 0 = unknown, 1 =  wifi, 2 = eth, 3 = ppp_4G, 4= ppp 3g, 5 = ppp 2g
    uint32_t current_frequency; //0xFFFFFFFF on invalid
    uint32_t freq0;
    uint32_t freq1;
    uint32_t freq2;
    uint8_t volume; // 0xFF on in valid'
    uint8_t remember_local_state;
    uint8_t gsm_csq;
    uint8_t gsm_band;
    uint8_t temperature_rev;
    uint8_t start_stop_rds;
} __attribute__((packed)) host_to_fm_frame_t;

#endif // HOST_DATA_LAYER_H