#ifndef IP_WDT_H
#define IP_WDT_H

#include <stdint.h>

#define WDT_THREAD_MQTT 0
#define WDT_THREAD_TCP 1
#define WDT_THREAD_GSM 2
#define WDT_THREAD_CDC 3
#define WDT_THREAD_ALL ((1 << WDT_THREAD_MQTT) | (1 << WDT_THREAD_GSM) | (1 << WDT_THREAD_CDC))

void ip_wdt_init(void);
void ip_wdt_feed(int thread_id);
void ip_wdt_start(void);

#endif
