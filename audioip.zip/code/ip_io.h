#ifndef IP_IO_H
#define IP_IO_H

#include "stdbool.h"
#include "stdint.h"

#define IO_OFF 0
#define IO_ON 1

#define IP_IO_OPTO_ON 1
#define IP_IO_OPTO_OFF 0

#define IP_IO_PA_ON 1
#define IP_IO_PA_OFF 0

#define IP_IO_OUT_FM_ON 1
#define IP_IO_OUT_CODEC_ON 0

#define IP_IO_IN_MIC_ON 1
#define IP_IO_IN_AUX_ON 0


#define IP_IO_GPIO_ON 1
#define IP_IO_GPIO_OFF 0

#define IP_IO_BUTTON_PRESSED 0
#define IP_IO_BUTTON_RELEASED 1

#define IP_IO32_OPTO_ON 1
#define IP_IO32_OPTO_OFF 0

#define IP_IO_PA_ON 1
#define IP_IO_PA_OFF 0

#define IP_IO_FM_ON 1
#define IP_IO_CODEC_ON 0

#define IP_IO_MIC_ON 1
#define IP_IO_AUX_ON 0

#define IP_IO_LED_ON 0
#define IP_IO_LED_OFF 1


#define IP_IO_4G_PWR_ON 1
#define IP_IO_4G_PWR_OFF 0

#define IP_IO_4G_PWR_KEY_LOW 1
#define IP_IO_4G_PWR_KEY_HIGH 0

#define IP_IO_4G_RESET_KEY_LOW 1
#define IP_IO_4G_RESET_KEY_HIGH 0


#define IP_IO_PA_ON 1
#define IP_IO_PA_OFF 0

#define IP_IO_OUT_FM_ON 1
#define IP_IO_OUT_CODEC_ON 0

#define IP_IO_IN_MIC_ON 1
#define IP_IO_IN_AUX_ON 0


#define IP_IO_GPIO_ON 1
#define IP_IO_GPIO_OFF 0


#define IP_IO32_OPTO_OFF 0

#define IP_IO_PA_ON 1
#define IP_IO_PA_OFF 0

#define IP_IO_LED_ON 0
#define IP_IO_LED_OFF 1

#define IP_IO_ISO_OUT_ON 1
#define IP_IO_ISO_OUT_OFF 0

#define IP_IO_4G_PWR_ON 1
#define IP_IO_4G_PWR_OFF 0

#define IP_IO_CODEC_ON 0
#define IP_IO_CODEC_OFF 1

#define IO_TYPE_LCD 0
#define IO_TYPE_LED 1

typedef enum
{
    BUTTON_MODE_INTERNET = 0,
    BUTTON_MODE_LINE = 1,
    BUTTON_MODE_MIC = 2
} ip_io_button_mode_t;

typedef union
{
    struct
    {
        uint32_t wdt : 1;
        uint32_t en_pa : 1;
        uint32_t gsm_pw_en : 1;
        uint32_t gsm_pwr_key : 1;
        uint32_t gsm_reset : 1;
        uint32_t rl1 : 1;
        uint32_t rl2 : 1;
        uint32_t led_network : 1;

        uint32_t led_server : 1;
        uint32_t led_stream : 1;
        uint32_t input1 : 1;
        uint32_t input2 : 1;
        uint32_t internal_pa : 1;
        uint32_t led_4g : 1;
        uint32_t led_wifi : 1;
        uint32_t led_eth : 1;

        uint32_t button : 2;
        uint32_t group : 1;
        uint32_t fan : 1;
        uint32_t pc817_on : 1;
        uint32_t pc817_off : 1;
        uint32_t NA : 10;
    } __attribute__((packed)) bit_name;
    uint32_t value;
} __attribute__((packed)) ip_io_mcu_io_t;


typedef struct
{
    int state;
    int dtmf1;  // on
    int dtmf2;  // off
    int count;
} dtmf_info_t;


bool ip_io_is_lcd_display();

/**
 * @brief           Get io expander mcu value
 * @retval          Expander value
 */
ip_io_mcu_io_t *ip_io_get_mcu_io_value(void);
int ip_io_get_temp();
int ip_flk_get_limit_level();

int ip_io_get_active_volume_button();

int ip_io_is_remote_btn_on();

void *ip_io_thread(void *arg);
bool ip_io_is_pa_on(void);
void *ip_io_dtmf_poll(void *arg);
void ip_io_set_if_lan_flag(int flag);
void ip_io_set_if_wifi_flag(int flag);
void ip_io_set_if_4g_flag(int flag);
void ip_io_init_hardware(void);
void ip_io_set_if_4g_toggle(void);

#endif