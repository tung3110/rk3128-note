#include "log_file.h"
#include "lwrb.h"
#include "pthread.h"
#include <time.h>
#include <stdarg.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <limits.h>
#include <libgen.h>
#include <sys/stat.h>
#include "ip_flk.h"
#include <dirent.h>

#define TIME_REMOVE_LOG_IN_DAY (2L) // (30L)

static lwrb_t m_log_file_ring_buffer;
static uint8_t *m_log_file_buffer = NULL;
static pthread_mutex_t m_mutex_log;
static pthread_t p_tid_log;
static char m_dir[512] = {0};

// Helper: get file modification time
static time_t get_mtime(const char *filepath) 
{
    struct stat st;
    if (stat(filepath, &st) == 0) {
        return st.st_mtime;
    }
    return (time_t)-1;
}


// auto remove log file
int log_file_auto_remove()
{
    // Check current year
    time_t now = time(NULL);
    struct tm *tm_now = localtime(&now);
    if (tm_now == NULL) {
        perror("localtime");
        return 1;
    }

    if (tm_now->tm_year + 1900 < 2024) {
        printf("System time is not correct (year < 2024). Abort cleanup\r\n");
        return 1;
    }

    DIR *dir;
    struct dirent *entry;
    char filepath[1024];
    time_t one_month_seconds = TIME_REMOVE_LOG_IN_DAY * 24L * 60L * 60L;  // Roughly 30 days

    dir = opendir(LOG_DIR);
    if (!dir) 
    {
        perror("opendir");
        return 1;
    }

    while ((entry = readdir(dir)) != NULL) 
    {
        // Skip . and ..
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
            continue;

        snprintf(filepath, sizeof(filepath), ".%s/%s", LOG_DIR, entry->d_name);

        time_t mtime = get_mtime(filepath);
        if (mtime == (time_t)-1) 
        {
            perror("stat");
            continue;
        }

        // Check if file is older than 1 month
        if ((now - mtime) > one_month_seconds) 
        {
            printf("Deleting old file: %s\n", filepath);
            if (unlink(filepath) != 0) 
            {
                perror("unlink");
            }
        }
    }

    closedir(dir);
    return 0;
}


void get_dir(char *out_dir)
{
    char path[512];

    // Get the path of the current executable
    ssize_t len = readlink("/proc/self/exe", path, sizeof(path) - 1);
    path[len] = '\0';  // Null-terminate the string

    // Get the directory of the executable
    char *dir = dirname(path);  // dirname() gives the directory part
    sprintf(out_dir, "%s", dir);
    printf("Current executable directory: %s\r\n", out_dir);
}

void log_file_flush()
{
    pthread_mutex_lock(&m_mutex_log);
    if (lwrb_get_full(&m_log_file_ring_buffer) > 0)
    {
        char log_buffer[1024];
        size_t read_size = lwrb_read(&m_log_file_ring_buffer, log_buffer, sizeof(log_buffer) - 1);
        if (read_size > 0)
        {
            log_buffer[read_size] = '\0'; // Null-terminate the string
            printf("%s", log_buffer); // Print to console or write to file
            
            time_t rawtime;
            struct tm *timeinfo;
            char log_name[PATH_MAX];
            char buffer[128];
            
            time(&rawtime);                 // Get current time (timestamp)
            timeinfo = localtime(&rawtime); // Convert to local time
        
            // Format the time into MMDDYYYY with fixed length for day, month, and year
            strftime(buffer, sizeof(buffer), "%m%d%Y", timeinfo);
            sprintf(log_name, "%s/%s_%s.txt", m_dir, ip_flk_get_4g_imei(), buffer);

            // commit to file
            // Open the file for writing
            FILE *file = fopen(log_name, "a");
            if (file) 
            {
                // Write something to the file (e.g., a simple message)
                fwrite(log_buffer, 1, read_size, file);
                // Close the file
                fclose(file);
            } 
            else 
            {
                perror("Error opening file");
            }
        }
    }
    pthread_mutex_unlock(&m_mutex_log);
}

void* log_thread(void* arg)
{
    memset(m_dir, 0, sizeof(m_dir));
    get_dir(m_dir);
    int dir_len = strlen(m_dir);
    struct stat st = {0};
    memcpy(&m_dir[dir_len], LOG_DIR, strlen(LOG_DIR));
    if (stat(m_dir, &st) == -1) 
    {
        // Directory doesn't exist, so create it
        if (mkdir(m_dir, 0700) == -1) 
        {
            perror("Error creating directory");
            return;
        }
        printf("Directory created: %s\n", m_dir);
    } 
    else 
    {
        printf("Directory already exists: %s\n", m_dir);
    }
    usleep(LOG_FILE_WRITE_INTERVAL_MS * 1000); // Sleep for the defined interval
    int check_log_counter = 0;
    while (1)
    {
        usleep(LOG_FILE_WRITE_INTERVAL_MS * 1000); // Sleep for the defined interval
        log_file_flush();
        if (check_log_counter++>= (86400/(LOG_FILE_WRITE_INTERVAL_MS/1000)))
        {
            log_file_auto_remove();
            check_log_counter = 0;
        }
    }
    return NULL;
}

void log_file_init()
{
    pthread_mutex_init(&m_mutex_log, NULL);
    m_log_file_buffer = malloc(LOG_FILE_RING_BUFFER_SIZE);
    if (m_log_file_buffer == NULL)
    {
        return;
    }
    lwrb_init(&m_log_file_ring_buffer, m_log_file_buffer, LOG_FILE_RING_BUFFER_SIZE);
    pthread_create(&p_tid_log, NULL, &log_thread, NULL);
}


void log_file_write(const char *fmt, ...)
{
    time_t rawtime;
    struct tm *timeinfo;
    char buffer[9]; // hh:mm:ss => 8 ký tự + 1 ký tự '\0'
    
    if (m_log_file_buffer == NULL)
    {
        return;
    }
    
    int time_size = 0;
    time(&rawtime);                 // Lấy thời gian hiện tại (timestamp)
    timeinfo = localtime(&rawtime);  // Chuyển sang dạng giờ địa phương

    strftime(buffer, sizeof(buffer), "%H:%M:%S", timeinfo); // Format thành chuỗi hh:mm:ss

    pthread_mutex_lock(&m_mutex_log);
    va_list args;
    va_start(args, fmt);
    
    char log_buffer[1024];
    time_size = sprintf(log_buffer, "%s: ", buffer);
    int max_len = sizeof(log_buffer) - time_size - 1; // Duy trì kích thước tối đa của log_buffer
    int len = vsnprintf(log_buffer+time_size, max_len, fmt, args);
    
    if (len > 0 && len < max_len)
    {
        lwrb_write(&m_log_file_ring_buffer, log_buffer, time_size+len);
    }
    
    va_end(args);
    pthread_mutex_unlock(&m_mutex_log);
}

