#ifndef ETH_MANAGER_H
#define ETH_MANAGER_H

#include <stdint.h>
#include <stdbool.h>

bool eth_is_connected(void);
char *eth_get_ip(void);

#endif