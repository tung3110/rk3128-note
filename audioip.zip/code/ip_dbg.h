#ifndef IP_DBG_H
#define IP_DBG_H

#include <stdint.h>
#include <stdbool.h>

#define DBG_LVL_ALL                 0
#define DBG_LVL_VERBOSE             1
#define DBG_LVL_INFO                2
#define DBG_LVL_WARN                3
#define DBG_LVL_ERROR               4
#define DBG_LVL_NOTHING             5
#define DBG_LVL                     DBG_LVL_INFO  

#ifndef DBG_ISR_ENABLE
#define DBG_ISR_ENABLE                0       // allow debug inside interrupt service
#define DBG_ISR_RING_BUFFER_SIZE      256
#endif

#ifndef DBG_NUMBER_OF_DEBUG_PORT
#define DBG_NUMBER_OF_DEBUG_PORT 2
#endif

// Uncomment to disable float print
#ifndef IP_DBG_HAS_FLOAT
//#define IP_DBG_HAS_FLOAT
#endif

#if 0
    #define KNRM  "\x1B[0m"
    #define KRED  RTT_CTRL_TEXT_RED
    #define KGRN  RTT_CTRL_TEXT_GREEN
    #define KYEL  RTT_CTRL_TEXT_YELLOW
    #define KBLU  RTT_CTRL_TEXT_BLUE
    #define KMAG  RTT_CTRL_TEXT_MAGENTA
    #define KCYN  RTT_CTRL_TEXT_CYAN
    #define KWHT  RTT_CTRL_TEXT_WHITE
#else
    #define KNRM  "\x1B[0m"
    #define KRED  "\x1B[31m"
    #define KGRN  "\x1B[32m"
    #define KYEL  "\x1B[33m"
    #define KBLU  "\x1B[34m"
    #define KMAG  "\x1B[35m"
    #define KCYN  "\x1B[36m"
    #define KWHT  "\x1B[37m"
#endif

#define DEBUG_RAW(args...)                      ip_dbg_print_raw(DBG_LVL_ERROR, args)
#define DEBUG_DUMP                              ip_dbg_dump
#define DEBUG_FLUSH                             ip_dbg_flush

#if DBG_ISR_ENABLE
    #define DEBUG_ISR(s, args...)               ip_dbg_print_isr(KBLU "[ISR] %s : " s KNRM, "", ##args)
#else
    #define DEBUG_ISR(s, args...)                            
#endif

#if (DBG_LVL_VERBOSE >= DBG_LVL)
#define A_LOGV(s, args...)               ip_dbg_print_raw(DBG_LVL_VERBOSE, KMAG "<%u> %s : " s KNRM,  ip_dbg_get_ms(), "", ##args)
#else
#define A_LOGV(s, args...)               // ip_dbg_print_nothing(s, ##args)
#endif

#if (DBG_LVL_INFO >= DBG_LVL)
#define A_LOGI(s, args...)                  ip_dbg_print_raw(DBG_LVL_INFO, KGRN "<%u> %s : " s KNRM,  ip_dbg_get_ms(), "", ##args)
#else
#define A_LOGI(s, args...)                  // ip_dbg_print_nothing(s, ##args)
#endif

#if (DBG_LVL_ERROR >= DBG_LVL)
#define A_LOGE(s, args...)                 ip_dbg_print_raw(DBG_LVL_ERROR, KRED "<%u> %s : " s KNRM,  ip_dbg_get_ms(), "", ##args)
#else
#define A_LOGE(s, args...)                 // ip_dbg_print_nothing(s, ##args)
#endif

#if (DBG_LVL_WARN >= DBG_LVL)
#define A_LOGW(s, args...)                  ip_dbg_print_raw(DBG_LVL_WARN, KYEL "<%u> %s : " s KNRM,  ip_dbg_get_ms(), "", ##args)
#else
#define A_LOGW(s, args...)                  // ip_dbg_print_nothing(s, ##args)
#endif

#define DEBUG_COLOR(color, s, args...)          ip_dbg_print_raw(color s KNRM, ##args)


typedef uint32_t (*ip_dbg_get_timestamp_ms_cb_t)(void);      // Get timestamp data 
typedef uint32_t (*ip_dbg_output_cb_t)(const void *buffer, uint32_t len);
typedef bool (*ip_dbg_lock_cb_t)(bool lock, uint32_t timeout_ms);
typedef void (*ip_dbg_fflush_cb_t)(bool lock);

/**
 * @brief           Initialize debug module
 * @param[in]       get_ms System get tick in ms
 */
void ip_dbg_init(ip_dbg_get_timestamp_ms_cb_t get_ms, ip_dbg_lock_cb_t lock_cb);

/**
 * @brief           Add call back function to debug array
 *                  Add your function to print data on screen, such as UartTransmit, CDCTransmit,...
 * @param[in]       output_cb Output data callback
 */
void ip_dbg_register_callback_print(ip_dbg_output_cb_t output_cb);

/**
 * @brief           Remove callback function from debug callback array
 * @param[in]       output_cb  Function which do you want to remove
 */
void ip_dbg_unregister_callback_print(ip_dbg_output_cb_t output_cb);

/**
 * @brief           Register flush callback
 */
void ip_dbg_register_fflush_cb(ip_dbg_fflush_cb_t flush_cb);

/**
 * @brief           Get timebase value in milliseconds
 * @retval          Current counter value of the timebase 
 */
uint32_t ip_dbg_get_ms(void);

/**
 * @brief           Print nothing on screen
 *                  Called when the DEBUG_FUNCTION level is less than the DBG_LVL value 
 */
void ip_dbg_print_nothing(const char *fmt, ...);

/**
 * @brief           Print data on screen, link standard C printf
 * @param[in]       fmt Pointer to the format want to print on the screen
 * @retval          Number of bytes was printed, -1 on error
 */
int32_t ip_dbg_print(const char *fmt, ...);

/**
 * @brief           Print data on screen, link standard C printf inside isr service
 * @param[in]       fmt Pointer to the format want to print on the screen
 * @retval          Number of bytes was printed, -1 on error
 */
void ip_dbg_print_isr(const char *fmt, ...);

/**
 * @brief           Flush all data in ringbuffer of ISR
 */
void ip_dbg_isr_ringbuffer_flush(void);


/**
 * @brief           Print raw data
 * @param[in]       level debug level
 * @param[in]       fmt Pointer to the data want to print on the screen      
 */
void ip_dbg_print_raw(uint8_t level, const char *fmt, ...);

/**
 * @brief           Dump hexa data to screen
 * @param[in]       data Pointer to the data want to print on the screen
 * @param[in]       len Number of bytes want to print
 * @param[in]       message Debug message
 * @retval          Number of bytes was printed, -1 on error    
 */
void ip_dbg_dump(const void* data, int32_t len, const char* message);

/**
 * @brief           Put byte to debug port
 * @param[in]       c Data to send
 */
void ip_dbg_putc(uint8_t c);

/**
 * @brief           Put byte to debug port in ISR context
 * @param[in]       c Data to send
 */
void ip_dbg_raw_isr(uint8_t c);

/**
 * @brief           Disable debug log output
 */
void ip_dbg_disable(void);

/**
 * @brief           Flush serial
 */
void ip_dbg_flush(void);

/**
 * @brief           Set debug level
 * @param[in]       level Debug level
 */
void ip_dbg_set_level(uint8_t level);

#endif // !IP_DBG_H
