#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <termios.h>
#include <stdint.h>

int app_serial_open(const char *name, uint32_t baudrate)
{
    struct termios tty; 
    int tty_fd;

    // Open serial port
    tty_fd = open(name, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (tty_fd == -1)
    {
        printf("Serial Port %s is not available\r\nPossible reasons:-\r\n"
               "1. Port is not present\r\n2. Port is in use by another app\r\n"
               "3. You may not have rights to access it\r\n",
               name);
        return -1;
    }
    printf("Serial port %s opened successfully, fd = %d\r\n", name, tty_fd);
    
    usleep(10000);
    tcflush(tty_fd, TCIOFLUSH);

    // Get current serial port attributes
    if (tcgetattr(tty_fd, &tty) != 0)  
    { 
        perror("tcgetattr failed"); 
        close(tty_fd);
        return -1; 
    } 

    // Set baud rate
    speed_t baud;
    switch (baudrate)
    {
        case 9600:
            baud = B9600;
            break;
        case 115200:
            baud = B115200;
            break;
        case 57600:
            baud = B57600;
            break;
        default:
            baud = B57600;
            break;
    }
    cfsetospeed(&tty, baud); 
    cfsetispeed(&tty, baud);

    // Configure 8N1 mode
    tty.c_cflag &= ~PARENB;  // No parity
    tty.c_cflag &= ~CSTOPB;  // 1 stop bit
    tty.c_cflag &= ~CSIZE;   // Clear data size bits
    tty.c_cflag |= CS8;      // 8 data bits

    tty.c_cflag |= CREAD | CLOCAL;  // Enable receiver, ignore modem control lines

    // Set raw input mode
    tty.c_lflag &= ~(ICANON | ECHO | ECHOE | ISIG);
    
    // Set raw output mode
    tty.c_oflag &= ~(OPOST | ONLCR | OCRNL);

    // Disable software flow control
    tty.c_iflag &= ~(IXON | IXOFF | IXANY | ICRNL | INLCR | IGNCR);

    // Set VMIN and VTIME
    tty.c_cc[VMIN] = 1;   // Wait for at least 1 character
    tty.c_cc[VTIME] = 5;  // Timeout = 500ms

    // Apply settings
    if (tcsetattr(tty_fd, TCSANOW, &tty) != 0)  
    {
        perror("tcsetattr failed"); 
        close(tty_fd);
        return -1;
    }

    return tty_fd;
}

int app_serial_read(int fd, uint8_t *buffer, uint32_t size)
{
    if (fd == -1)
    {
        printf("[%s] Invalid FD\r\n", __FUNCTION__);
        return -1;
    }

    return read(fd, buffer, size);
}

int app_serial_write(int fd, uint8_t *buffer, uint32_t size)
{
    if (fd == -1)
    {
        return -1;
    }

    return write(fd, buffer, size);
}

int app_serial_close(int fd)
{
    if (fd == -1)
    {
        return -1;
    }

    close(fd);                                 // close the serial port
    return 0;
}
