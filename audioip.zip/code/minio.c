#include "minio.h"
#include "device_config.h"
#include "utils.h"
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include "ip_flk.h"

void minio_upload_log(char *object_name)
{
    minio_info_t *minio = app_flash_get_minio();
    if (access(object_name, F_OK) == 0) 
    {
        // sh ./minio_upload.sh http://logurlcom:9100 access secret bucket amz.c

        utils_run_shell_cmd(NULL, 0, true, "sh ./minio_upload.sh %s %s %s %s %s", 
                                            minio->url, minio->access_key, minio->secret_key, minio->bucket, 
                                            object_name);
    } 
    else 
    {
        printf("File does not exist: %s\r\n", object_name);
    }
}