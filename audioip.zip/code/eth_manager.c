#include "eth_manager.h"
#include "utils.h"
#include "string.h"

static const char *ETH_IP_CMD = "timeout 3 ip -4 addr show eth0 | grep -oP '(?<=inet\\s)\\d+(\\.\\d+){3}'";

char *eth_get_ip(void)
{
    static char output_buffer[256];
    memset(output_buffer, 0, sizeof(output_buffer));
    utils_run_shell_cmd(output_buffer, sizeof(output_buffer), true, ETH_IP_CMD);
    char *p = strstr(output_buffer, "\n");
    if (p) *p = 0;
    return output_buffer;
}