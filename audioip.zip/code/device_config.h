#ifndef _DEVICE_CONIG_H_
#define _DEVICE_CONIG_H_

#include <stdint.h>
#include <stdbool.h>

#define FIRMWARE_VERSION "RK3_007"

#define APP_FLASH_MAX_GROUP_SUPPORT 10
#define APP_FLASH_MAX_GROUP_NAME_LEN 68
#define APP_FLASH_DEVICE_NAME_MAX_LENGTH              128
#define SPEAKER_CLASS_OFF 0
#define SPEAKER_CLASS_AB 1
#define SPEAKER_CLASS_D 2
#define APP_FLASH_MINIO_URL_LENGTH  128
#define APP_FLASH_MINIO_ACCESS_KEY_LENGTH  96
#define APP_FLASH_MINIO_SECRET_KEY_LENGTH  96
#define APP_FLASH_MINIO_BUCKET_LENGTH  64


typedef struct
{
    char url[128];
    int port;
    char username[64];
    char password[64];
} broker_info_t;

typedef struct
{
    char url[APP_FLASH_MINIO_URL_LENGTH];
    char access_key[APP_FLASH_MINIO_ACCESS_KEY_LENGTH];
    char secret_key[APP_FLASH_MINIO_SECRET_KEY_LENGTH];
    char bucket[APP_FLASH_MINIO_BUCKET_LENGTH];
} minio_info_t;

typedef struct
{
    uint8_t priority;
    char group_id[APP_FLASH_MAX_GROUP_NAME_LEN];
} __attribute__((packed)) app_flash_group_info_t;

typedef enum
{
    FREQ_CURRENT,
    FREQ_0,
    FREQ_1,
    FREQ_2,
    FREQ_MAX
} fm_freq_t;

typedef struct
{
    char imei[48];
    char ccid[33];
    char imsi[33];
    char master[9][48];
    char stream_url[164];
    uint8_t volume[3];
    uint8_t mode;
    broker_info_t mqtt;
    char last_stream_master[48];
    int reset_counter;
    int reset_reason;
    int debug_level;
    int log_to_tty;
    int log_level;
    int log_to_file;
    int relay_delay_on;
    int relay_delay_off_1;
    int relay_delay_off_2;
    int dtmf_on;
    int dtmf_off;
    int dtmf_count;
    int active_level;
    bool mute;
    char wifi_name[64];
    char wifi_password[64];
    bool enable;
    uint8_t protocol_type;
    app_flash_group_info_t group_info[APP_FLASH_MAX_GROUP_SUPPORT];
    char last_stream_group_id[APP_FLASH_MAX_GROUP_NAME_LEN];
    char device_name[APP_FLASH_DEVICE_NAME_MAX_LENGTH+1];
    uint8_t spk_class;
    uint32_t freq[4];
    minio_info_t minio;
} device_config_t;


#endif // DEVICE_CONFIG_H