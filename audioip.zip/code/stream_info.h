#include <stddef.h>
#include <stdint.h>

#ifndef STREAM_INFO_H
#define STREAM_INFO_H

typedef enum
{
    STREAM_IDLE = 0,
    STREAM_RUNNING = 1,
    STREAM_STOP = 2,
    STREAM_PREPARE = 3,
} stream_state_t;

typedef struct
{
    size_t downloaded;
    size_t stream_time; // in second
    stream_state_t state;
    int mute;
    char url[256];
} stream_monitor_info_t;

#endif