#ifndef WIFI_MANAGER_H
#define WIFI_MANAGER_H

#include <stdint.h>
#include <stdbool.h>

#define MAX_SSID_LENGTH 64
#define MAX_WIFI_COUNT 10
typedef struct 
{
    char ssid[MAX_SSID_LENGTH];
    float rssi;
} wifi_info_t;

typedef void (*on_wifi_scan_callback)(wifi_info_t *info, int len);

bool wifi_manager_is_scanning(void);
void wifi_manager_scan(on_wifi_scan_callback callback);
bool wifi_manager_connect(char *ssid, char *password);
char *wifi_get_ip(void);
bool wifi_get_name_and_rssi(char **name, int *rssi);
bool wifi_is_connected();

#endif