#include "utils.h"
#include <stdio.h>
#include <errno.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <arpa/inet.h>
#include "sys/un.h"
#include <fcntl.h>
#include <poll.h>
#include <sys/select.h>
#include <sys/ioctl.h>
#include <stddef.h>
#include <stdarg.h>
#include <signal.h>
#include <sys/wait.h>
#include "ip_dbg.h"
#include "board_hw.h"
#include <regex.h>
#include <arpa/inet.h>
#include <ctype.h>

#define MAX_MATCHES 1
#define MAX_LENGTH 256

uint32_t utils_sys_get_second(void)
{
    return time(NULL);
}

char *utils_get_free_ram()
{
    static char m_free_ram[256];
    char tmp[256];
    memset(m_free_ram, 0, sizeof(m_free_ram));
    memset(tmp, 0, sizeof(tmp));
    utils_run_shell_cmd(tmp, sizeof(tmp), NULL, "/usr/bin/timeout 2 free");
    char *p = strstr(tmp, "\nSwap:");

    if (p)
    {
        *p = 0;
        char *q = strstr(tmp, "\nMem:");
        if (q)
        {
            q+=5;
            int count = 3;
            char *start = q+5;
            while (count-- > 0)
            {
                while (*q == ' ' && q < p)
                {
                    q++;
                }
                if (count)
                {
                    while (*q++ != ' ');
                }

                if (count == 0)
                {
                    start = q;
                    while (*q++ != ' ');
                }
            }
   
            *(q-1) = 0;
            strcpy(m_free_ram, start);
        }
    }


    return m_free_ram;
}


char *utils_cpu_get_load_avg()
{
    static char m_load_avg[128];
    memset(m_load_avg, 0, sizeof(m_load_avg));
    utils_run_shell_cmd(m_load_avg, 128, false, "/usr/bin/timeout 2 cat /proc/loadavg");
    return m_load_avg;
}


void utils_get_active_interface(char *interface)
{
    char *shell_stdout = calloc(1024, 1);
    if (shell_stdout)
    {
        utils_run_shell_cmd(shell_stdout, 1024, true, "ip addr show | awk \'/inet.*brd/{print $NF}\'");
        snprintf(interface, 32, "%s", shell_stdout);
        char *p = strstr(interface, "\n");
        if (p) *p = '\0';
        p = strstr(interface, "eth0");
        if (p)
        {
            sprintf(interface, "%s", "LAN");
        }
        else if (strstr(interface, "wlp8s0"))
        {
            sprintf(interface, "%s", "WIFI");
        }
        else if (strstr(interface, "wlan0"))
        {
            sprintf(interface, "%s", "WIFI");
        }

        free(shell_stdout);
    }
    else
    {
        sprintf(interface, "%s", "NA");
    }
}



int utils_run_shell_cmd(char *buffer, int buffer_size, bool wait_to_complete, const char *fmt, ...)
{
    FILE *sub;
    pid_t subpid;
    int status = -1;
    int len;

    char *body = calloc(4096, 1);
    if (!body)
    {
        A_LOGI("[%s] No mem\r\n", __FUNCTION__);
        goto end;
    }

    va_list arg_ptr;

    va_start(arg_ptr, fmt);
    len = vsnprintf(body, 4096, fmt, arg_ptr);
    va_end(arg_ptr);


    // printf("Shell '%s'\r\n", body);

    sub = popen(body, "r");
    if (!sub) 
    {
        /* popen() failed. */
        A_LOGW("Run shell cmd %s failed ", body);
        perror(":");
        goto end;
    }
    // A_LOGV("Subprocess = %d\r\n", sub);

    /* Read the first line from sub. It contains the PID for the command. */
    int size = 0;
    if (buffer)
    {
        while (1)
        {
            if (feof(sub) || ferror(sub))
            {
                A_LOGW("Get PID for the command failed\r\n");
                break;
            }
            else
            {
                int max_size = buffer_size-size-1;
                char *p = fgets(buffer+size, max_size, sub);
                if (p && strlen(p))
                {
                    // A_LOGI("%u bytes\r\n", strlen(p));
                    DEBUG_RAW(p);
                    size += strlen(p);
                }
                else
                {
                    break;
                }
            }
        }
    }

close:
    if (wait_to_complete)
    {
        char tmp[256];
        // DEBUG_RAW("------Subprocess output--------\r\n");
        while (fgets(tmp, 255, sub) != NULL)
        {
            // DEBUG_RAW("%s", tmp);
        }
        // DEBUG_RAW("-------End--------\r\n");
    }
    errno = 0;
    do 
    {
        status = pclose(sub);
        board_hw_sleep(100L);
    } while (status == -1 && errno == EINTR);

    if (status) 
    {
        /* Problem: sub exited with nonzero exit status 'status',
         * or if status == -1, some other error occurred. */
        A_LOGW("Subprocess %s close failed %d\r\n", body, status);
    } 
end:
    if (body)
    {
        free(body);
    }
    return status;
}



int utils_reboot(void)
{
    int val = utils_run_shell_cmd(NULL, 0, false, "sudo reboot -f");
    return val;
}

uint32_t utils_get_number_from_string(uint16_t begin_addr, char* buffer)
{
    uint32_t Value = 0;
    uint16_t tmp_count = 0;

    tmp_count = begin_addr;
    Value = 0;
    while(buffer[tmp_count] && tmp_count < 1024)
    {
        if(buffer[tmp_count] >= '0' && buffer[tmp_count] <= '9')
        {
            Value *= 10;
            Value += buffer[tmp_count] - 48;
        }
        else 
        {
            break;
        }

        tmp_count++;
    }

    return Value;
}

// Function to check if the string is an IP address (IPv4 or IPv6)
int is_ip_address(const char *name) {
    struct sockaddr_in sa;
    struct sockaddr_in6 sa6;

    // Try to parse as IPv4
    if (inet_pton(AF_INET, name, &(sa.sin_addr)) == 1) {
        return 1;  // It's a valid IPv4 address
    }

    // Try to parse as IPv6
    if (inet_pton(AF_INET6, name, &(sa6.sin6_addr)) == 1) {
        return 1;  // It's a valid IPv6 address
    }

    return 0;  // Not an IP address
}

// Function to check if the string is a valid domain name
int utils_is_domain_name(const char *name) 
{
    if (!name)
    {
        return 0;
    }

    if (name[0] > '9' || name[0] < '0')
    {
        return 1;
    }
    if (is_ip_address(name)) 
    {
        return 0;  // It's an IP, not a domain
    }

    // Check if the name contains only valid domain name characters
    int len = strlen(name);
    for (int i = 0; i < len; i++) 
    {
        if (!isalnum(name[i]) && name[i] != '-' && name[i] != '.') 
        {
            return 0;  // Invalid character for domain name
        }
    }

    return 1;  // It's a valid domain name
}

int utils_get_cpu_temperature()
{
    char tmp[128];
    memset(tmp, 0, sizeof(tmp));
    utils_run_shell_cmd(tmp, sizeof(tmp), true, "timeout 3 cat /sys/class/thermal/thermal_zone1/temp");
    char *p = strstr(tmp, "\n");
    if (p) *p = '\0';
    // A_LOGI("Temperature: %s", tmp);
    return atoi(tmp)/1000;
}

char *utils_get_disk_usage()
{
    static char tmp[128];
    memset(tmp, 0, sizeof(tmp));
    utils_run_shell_cmd(tmp, sizeof(tmp), true, "timeout 3 df -h --total | awk '/total/ {print $2, $3, $4, $5}'");
    char *p = strstr(tmp, "\n");
    if (p)
    {
        *p = 0;
    }
    else
    {
        tmp[127] = 0;
    }
    return tmp;
}
