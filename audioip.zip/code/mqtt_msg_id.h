#ifndef MQTT_MSQ_ID_H
#define MQTT_MSQ_ID_H

#define MQTT_MSG_ID_STREAM 0
#define MQTT_MSG_ID_STREAM_PREPARE 1
#define MQTT_MSG_ID_STREAM_START 2
#define MQTT_MSG_ID_STREAM_STOP 0

#define MSG_ID_SET_CFG 1
#define MSG_ID_GET_CFG 2
#define MSG_ID_CFG_ACK 3

#endif