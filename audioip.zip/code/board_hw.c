#include "board_hw.h"
#include <unistd.h>


void board_hw_sleep(uint32_t ms)
{
    usleep(ms*1000);
}