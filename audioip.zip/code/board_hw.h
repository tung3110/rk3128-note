#ifndef BOARD_HW_H
#define BOARD_HW_H

#include <stdint.h>



#define GPIO_LED_RED_PATH "/sys/class/gpio/gpio41/value"
#define GPIO_LED_GREEN_PATH "/sys/class/gpio/gpio44/value"
#define GPIO_CLASS_D_MUTE_PATH "/sys/class/gpio/gpio42/value"
#define GPIO_FM_RELAY_PATH "/sys/class/gpio/gpio46/value"
#define GPIO_CODEC_MUTE_PATH "/sys/class/gpio/gpio45/value"

/*
 * @brief Sleep in miliseconds
*/
void board_hw_sleep(uint32_t ms);

#endif // BOARD_HW_H