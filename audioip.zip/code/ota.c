#include "ota.h"
#include "ip_mqtt.h"
#include <pthread.h>
#include <errno.h>
#include "ip_dbg.h"
#include "app_md5.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "utils.h"
#include "board_hw.h"
#include <assert.h>
#include "ip_flk.h"

static ota_url_t m_ota_url;
static pthread_t p_tid_ota;


static int process_firmware_update_on_file(char *filename)
{
    /**
     * Download firmware region detail
     * -------------------------------
     *         16 bytes header ota_image_header_t
     * -------------------------------
     *         Raw firmware
     * -------------------------------
     *         4 bytes CRC32-SUM or 16 bytes MD5, depend on checksum method
     * -------------------------------
    */
    int retval = -1;
    int file_size = -1;
    FILE *f_in = NULL, *f_out = NULL;
    char *out_file_name = NULL;

    if (!filename)
    {
        goto end;
    }

    out_file_name = calloc(strlen(ip_flk_get_binary_path())+16, 1);
    if (!out_file_name)
    {
        A_LOGW("Malloc file name failed\r\n");
        goto end;
    }

    sprintf(out_file_name, "%s.udfw", ip_flk_get_binary_path());

    // Get file size
    f_in = fopen(filename, "r");
    f_out = fopen(out_file_name, "w");
    if (!f_in || !f_out)
    {
        A_LOGW("Open file failed\r\n");
        goto end;
    }

    // Get file size
    fseek(f_in, 0L, SEEK_END);
    file_size = ftell(f_in);
    fseek(f_in, 0L, SEEK_SET);
    A_LOGI("OTA firmware size %d\r\n", file_size);

    if (!(file_size > 32 && file_size < MAX_OTA_FILE_SIZE))     // 16 bytes header
    {
        A_LOGW("Invalid file size\r\n");
        goto end;
    }

    // Check header
    ota_image_header_t header;
    uint8_t expect_md5[16];
    memset(&header, 0, sizeof(header));
    
    // Read hdr
    fread(header.raw, 1, sizeof(ota_image_header_t), f_in);

    // Read 16 bytes md5
    fseek(f_in, file_size-16, SEEK_SET);
    fread(expect_md5, 1, 16, f_in);
    
    if (memcmp(header.name.header, FIRMWARE_SIGNATURE, 3))
    {
        A_LOGW("Invalid header %.*s\r\n", 3, header.name.header);
        goto end;
    }

    A_LOGI("%.*s, fw %.*s, hw %.*s, build on %d/%02d/%02d\r\n",
                3, header.name.header,
                3, header.name.fw_version,
                3, header.name.hw_version,
                header.name.release_year+2000,
                header.name.release_month,
                header.name.release_date);

    // Seek to firmware raw data
    fseek(f_in, 16L, SEEK_SET);

    // Calculate CRC
    app_md5_ctx	md5_ctx;
    uint8_t calculate_md5[16];
    app_md5_init(&md5_ctx);

    for (int i = 0; i < file_size - 32; i++)
    {
        uint8_t tmp[1];
        fread(tmp, 1, 1, f_in);
        fwrite(tmp, 1, 1, f_out);
        app_md5_update(&md5_ctx, tmp, 1);
    }
    app_md5_final(calculate_md5, &md5_ctx);
            
    if (memcmp(calculate_md5, expect_md5, 16) == 0)
    {
        A_LOGW("Valid CRC\r\n");
        retval = 0;
    }
    else
    {
        A_LOGW("Invalid firmware CRC\r\n");
        DEBUG_DUMP(expect_md5, 16, "Expected");
        DEBUG_DUMP(calculate_md5, 16, "Calculated");
        retval = -1;
    }

end:
    if (f_in)
    {
        fclose(f_in);
        remove(filename);
        f_in = NULL;
    }

    if (f_out)
    {
        fclose(f_out);
        f_out = NULL;
        // remove(out_file_name);
    }

    if (retval == 0)
    {
        // Delete old binaray
        remove(ip_flk_get_binary_path());
        // Update new binaray
        rename(out_file_name, ip_flk_get_binary_path());

        A_LOGI("Rename file %s to %s\r\n", out_file_name, ip_flk_get_binary_path());
    }

    if (out_file_name)
        free(out_file_name);

    return retval;
}

static void* ota_task(void* arg)
{
    char *download_info = calloc(2048, 1);
    assert(download_info);
    int status = 0;
    if (strlen(m_ota_url.username) && strlen(m_ota_url.password))
    {
        utils_run_shell_cmd(download_info, 2048, true, "timeout 3600 wget -q -O /tmp/firmware.bin --user '%s' --password '%s' %s", 
            m_ota_url.username, 
            m_ota_url.password,
            m_ota_url.url);
    }
    else
    {
        utils_run_shell_cmd(download_info, 2048, true, "timeout 3600 wget -q -O /tmp/firmware.bin %s", m_ota_url.url);
    }

    if (status == 0)
    {
        ip_mqtt_dbg("Download firmware completed");
        board_hw_sleep(1000);
        status = process_firmware_update_on_file("/tmp/firmware.bin");
        ip_mqtt_dbg("Update firmware %s", status ? "failed" : "success" );
        if (status)
        {
            utils_run_shell_cmd(NULL, 0, true, "sudo timeout 3 chmod 777 ./amz");
            utils_run_shell_cmd(NULL, 0, true, "sudo timeout 5 sync");
        }
        board_hw_sleep(5000);
        utils_reboot();
    }
    else
    {
        A_LOGW("Download firmware failed\r\n");
        if (strlen(download_info))
        {
            ip_mqtt_dbg("Download failed %d", status);
        }
    }
    free(download_info);
    memset(&m_ota_url, 0, sizeof(m_ota_url));
}


void ota_start(char *url, char *username, char *password)
{
    if (strlen(m_ota_url.url) > 0)
    {
        ip_mqtt_dbg("OTA already running\r\n");
        return;
    }

    sprintf(m_ota_url.url, "%s", url);
    if (username)
    {
        sprintf(m_ota_url.username, "%s", username);
    }
    if (password)
    {
        sprintf(m_ota_url.password, "%s", password);
    }
    pthread_create(&p_tid_ota, NULL, &ota_task, NULL);
    pthread_detach(p_tid_ota);
}